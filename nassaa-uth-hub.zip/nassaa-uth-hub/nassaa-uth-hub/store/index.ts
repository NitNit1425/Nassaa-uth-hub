'use client'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, Game, Slot } from '@/types/supabase'

// ── AUTH STORE ──
interface AuthStore {
  user: User | null
  setUser: (u: User | null) => void
}
export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({ user: null, setUser: (user) => set({ user }) }),
    { name: 'nuh-auth' }
  )
)

// ── BOOKING STORE ──
export interface BookingState {
  step: 1 | 2 | 3 | 4 | 5
  selectedGame: Game | null
  selectedDate: Date | null
  selectedSlot: Slot | null
  players: number
  name: string
  phone: string
  email: string
  paymentId: string | null
  bookingRef: string | null
  setStep: (s: 1|2|3|4|5) => void
  setGame: (g: Game) => void
  setDate: (d: Date) => void
  setSlot: (s: Slot) => void
  setPlayers: (n: number) => void
  setContact: (name: string, phone: string, email: string) => void
  setPaymentSuccess: (paymentId: string, bookingRef: string) => void
  reset: () => void
}

const bookingInitial = {
  step: 1 as const, selectedGame: null, selectedDate: null,
  selectedSlot: null, players: 1, name: '', phone: '', email: '',
  paymentId: null, bookingRef: null,
}

export const useBookingStore = create<BookingState>()((set) => ({
  ...bookingInitial,
  setStep:    (step) => set({ step }),
  setGame:    (selectedGame) => set({ selectedGame, step: 2 }),
  setDate:    (selectedDate) => set({ selectedDate }),
  setSlot:    (selectedSlot) => set({ selectedSlot, step: 3 }),
  setPlayers: (players) => set({ players }),
  setContact: (name, phone, email) => set({ name, phone, email }),
  setPaymentSuccess: (paymentId, bookingRef) => set({ paymentId, bookingRef, step: 5 }),
  reset:      () => set(bookingInitial),
}))

// ── UI STORE ──
interface UIStore {
  isLoading: boolean
  mobileMenuOpen: boolean
  chatOpen: boolean
  theme: 'dark' | 'light'
  setLoading: (v: boolean) => void
  toggleMenu: () => void
  toggleChat: () => void
  toggleTheme: () => void
}
export const useUIStore = create<UIStore>()(
  persist(
    (set) => ({
      isLoading: true,
      mobileMenuOpen: false,
      chatOpen: false,
      theme: 'dark',
      setLoading:   (isLoading) => set({ isLoading }),
      toggleMenu:   () => set((s) => ({ mobileMenuOpen: !s.mobileMenuOpen })),
      toggleChat:   () => set((s) => ({ chatOpen: !s.chatOpen })),
      toggleTheme:  () => set((s) => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),
    }),
    { name: 'nuh-ui', partialize: (s) => ({ theme: s.theme }) }
  )
)
