'use client'
import { useEffect, useRef } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { gsap } from 'gsap'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Sphere, MeshDistortMaterial, Float } from '@react-three/drei'

function BowlingBall() {
  return (
    <Float speed={2} rotationIntensity={1.5} floatIntensity={1}>
      <Sphere args={[1.4, 64, 64]}>
        <MeshDistortMaterial
          color="#00d4ff" distort={0.25} speed={1.5}
          roughness={0.05} metalness={0.9}
          emissive="#001a33" emissiveIntensity={0.4}
        />
      </Sphere>
      {/* Ball holes */}
      {[[-0.3,0.5,1.2],[0.1,0.5,1.2],[0.3,0.2,1.2]].map(([x,y,z],i) => (
        <Sphere key={i} args={[0.09,16,16]} position={[x,y,z]}>
          <meshBasicMaterial color="#000" />
        </Sphere>
      ))}
    </Float>
  )
}

const letters = 'LEVEL UP YOUR GAME'.split('')
const tagline = 'NASSAA UTH HUB — BESANT NAGAR, CHENNAI'

export function HeroSection() {
  const statsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!statsRef.current) return
    const nums = statsRef.current.querySelectorAll('[data-target]')
    nums.forEach((el) => {
      const target = parseInt(el.getAttribute('data-target') || '0')
      gsap.from(el, {
        textContent: 0, duration: 2, delay: 3.2, ease: 'power2.out',
        snap: { textContent: 1 },
        onUpdate() { el.textContent = Math.ceil(parseFloat(el.textContent || '0')).toLocaleString() },
      })
    })
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-16"
      style={{ background: 'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(0,100,200,0.18) 0%, transparent 70%), radial-gradient(ellipse 40% 40% at 80% 70%, rgba(178,0,255,0.12) 0%, transparent 60%)' }}>

      {/* 3D WebGL sphere */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-70 pointer-events-none hidden lg:block">
        <Canvas camera={{ position: [0, 0, 4.5], fov: 45 }}>
          <ambientLight intensity={0.3} />
          <pointLight position={[5, 5, 5]} intensity={2} color="#00d4ff" />
          <pointLight position={[-5, -5, 5]} intensity={1.5} color="#b200ff" />
          <spotLight position={[0, 10, 0]} intensity={1} color="#ff0099" />
          <BowlingBall />
        </Canvas>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          {/* Eyebrow */}
          <motion.div
            className="font-mono text-[0.72rem] tracking-[0.4em] text-[#00d4ff] uppercase mb-5 flex items-center gap-2"
            initial={{ opacity:0, x:-30 }} animate={{ opacity:1, x:0 }} transition={{ delay:2.9, duration:0.6 }}
          >
            <span className="w-8 h-px bg-[#00d4ff]/50" />
            📍 Besant Nagar, Chennai — Est. 2024
          </motion.div>

          {/* Letter-by-letter headline */}
          <h1 className="font-orbitron font-black leading-[0.92] mb-6" style={{ fontSize:'clamp(3rem,8vw,6.5rem)' }}>
            <div className="overflow-hidden">
              <motion.div className="flex flex-wrap gap-x-[0.15em]">
                {'LEVEL UP'.split('').map((c, i) => (
                  <motion.span key={i} className="grad-headline inline-block"
                    initial={{ y: 80, opacity: 0 }}
                    animate={{ y: 0,  opacity: 1 }}
                    transition={{ delay: 3.0 + i * 0.04, duration: 0.5, ease: [0.23,1,0.32,1] }}
                  >{c === ' ' ? '\u00a0' : c}</motion.span>
                ))}
              </motion.div>
            </div>
            <div className="overflow-hidden mt-1">
              <motion.div className="flex flex-wrap gap-x-[0.15em]">
                {'YOUR GAME'.split('').map((c, i) => (
                  <motion.span key={i} className="inline-block"
                    style={{ background:'linear-gradient(135deg,#b200ff,#ff0099)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}
                    initial={{ y: 80, opacity: 0 }}
                    animate={{ y: 0,  opacity: 1 }}
                    transition={{ delay: 3.1 + i * 0.04, duration: 0.5, ease: [0.23,1,0.32,1] }}
                  >{c === ' ' ? '\u00a0' : c}</motion.span>
                ))}
              </motion.div>
            </div>
          </h1>

          {/* Sub */}
          <motion.p
            className="text-white/55 text-lg leading-relaxed max-w-[480px] mb-8"
            initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:3.5, duration:0.6 }}
          >
            Chennai&apos;s most immersive gaming universe — Bowling, VR, Arcade & beyond. Every visit feels like a new adventure.
          </motion.p>

          {/* CTAs */}
          <motion.div className="flex flex-wrap gap-4" initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:3.7 }}>
            <Link href="/booking">
              <motion.button
                className="font-orbitron font-bold text-sm tracking-widest text-white px-8 py-4 rounded magnetic-btn"
                style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}
                whileHover={{ scale:1.04, boxShadow:'0 12px 40px rgba(0,212,255,0.5)' }}
                whileTap={{ scale:0.97 }}
              >
                🎮 BOOK YOUR SLOT
              </motion.button>
            </Link>
            <motion.button
              className="font-orbitron font-bold text-sm tracking-wider text-[#00d4ff] px-8 py-4 rounded border border-[#00d4ff]/40 hover:bg-[#00d4ff]/10 transition-all"
              whileHover={{ scale:1.04 }} whileTap={{ scale:0.97 }}
              onClick={() => document.getElementById('games')?.scrollIntoView({ behavior:'smooth' })}
            >
              EXPLORE GAMES →
            </motion.button>
          </motion.div>
        </div>

        {/* Mobile sphere placeholder */}
        <div className="lg:hidden flex justify-center">
          <div className="w-48 h-48 rounded-full border border-[#00d4ff]/20 bg-[#00d4ff]/05 flex items-center justify-center text-7xl animate-float">
            🎳
          </div>
        </div>
      </div>

      {/* Stats bar */}
      <motion.div
        ref={statsRef}
        className="absolute bottom-10 left-0 right-0 flex justify-center gap-12 flex-wrap px-6"
        initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:3.9 }}
      >
        {[
          { val: 50,   suffix: '+', label: 'Gaming Titles' },
          { val: 1200, suffix: '+', label: 'Happy Players' },
          { val: 8,    suffix: '',  label: 'VR Zones' },
          { val: 12,   suffix: '',  label: 'Bowling Lanes' },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <div className="font-orbitron font-black text-3xl grad-headline-2" data-target={s.val}>
              {s.val}{s.suffix}
            </div>
            <div className="font-mono text-xs tracking-widest uppercase text-white/30 mt-0.5">{s.label}</div>
          </div>
        ))}
      </motion.div>

      {/* Scroll hint */}
      <motion.div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 opacity-40"
        animate={{ y: [0,8,0] }} transition={{ duration:2, repeat:Infinity }}
      >
        <span className="font-mono text-[0.6rem] tracking-[0.3em] text-[#00d4ff] uppercase">Scroll</span>
        <div className="w-4 h-4 border-r-2 border-b-2 border-[#00d4ff] rotate-45" />
      </motion.div>
    </section>
  )
}
