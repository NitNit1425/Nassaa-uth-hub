'use client'
import { motion } from 'framer-motion'

export function ContactSection() {
  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Map */}
        <motion.div initial={{ opacity:0, x:-40 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }}
          className="h-80 rounded-2xl border border-[#00d4ff]/20 bg-[#00d4ff]/03 flex items-center justify-center flex-col gap-4 relative overflow-hidden">
          <div className="absolute inset-0"
            style={{ backgroundImage:'linear-gradient(rgba(0,212,255,0.06) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.06) 1px,transparent 1px)', backgroundSize:'30px 30px', animation:'gridMove 8s linear infinite' }} />
          <motion.div className="text-6xl relative z-10" animate={{ y:[0,-10,0] }} transition={{ duration:2.5, repeat:Infinity }}
            style={{ filter:'drop-shadow(0 0 20px rgba(0,212,255,0.8))' }}>📍</motion.div>
          <div className="relative z-10 font-mono text-sm tracking-widest text-[#00d4ff] bg-[rgba(0,10,30,0.8)] px-4 py-2 rounded border border-[#00d4ff]/30">
            NASSAA UTH HUB
          </div>
        </motion.div>

        {/* Info */}
        <motion.div initial={{ opacity:0, x:40 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }}>
          <div className="section-tag">📍 FIND US</div>
          <h2 className="font-orbitron font-black text-3xl mb-3"><span className="grad-headline-2">Visit Us</span></h2>
          <p className="text-white/50 leading-relaxed mb-6">Besant Nagar, Chennai<br />Tamil Nadu, India — 600090</p>
          {[
            { icon:'📞', text:'+91 98765 43210' },
            { icon:'✉️', text:'hello@nassaauthhub.in' },
            { icon:'⏰', text:'Mon–Sun: 10AM – 11PM' },
          ].map(item => (
            <div key={item.icon} className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-[#00d4ff]/08 border border-[#00d4ff]/20 flex items-center justify-center">{item.icon}</div>
              <span className="text-white/65">{item.text}</span>
            </div>
          ))}
          <div className="flex gap-3 mt-5">
            {['📸','🎵','▶️','💬'].map(icon => (
              <button key={icon} className="w-10 h-10 rounded-lg border border-[#00d4ff]/20 bg-[#00d4ff]/05 flex items-center justify-center hover:border-[#00d4ff]/50 hover:bg-[#00d4ff]/15 hover:-translate-y-1 transition-all">
                {icon}
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <div className="mt-16 pt-6 border-t border-[#00d4ff]/10 flex items-center justify-between flex-wrap gap-4">
        <div className="font-orbitron font-black text-sm tracking-widest" style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          ⚡ NASSAA UTH HUB
        </div>
        <div className="text-white/20 text-sm">© 2025 Nassaa Uth Hub, Besant Nagar, Chennai. All rights reserved.</div>
      </div>
    </section>
  )
}
