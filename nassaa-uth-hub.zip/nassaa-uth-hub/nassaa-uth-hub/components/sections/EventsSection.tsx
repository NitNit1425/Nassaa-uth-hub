'use client'
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import type { GameEvent } from '@/types/supabase'
import { format, differenceInSeconds } from 'date-fns'

function Countdown({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState({ d:0, h:0, m:0, s:0 })

  useEffect(() => {
    const calc = () => {
      const diff = differenceInSeconds(new Date(targetDate), new Date())
      if (diff <= 0) return
      setTimeLeft({ d: Math.floor(diff/86400), h: Math.floor((diff%86400)/3600), m: Math.floor((diff%3600)/60), s: diff%60 })
    }
    calc()
    const id = setInterval(calc, 1000)
    return () => clearInterval(id)
  }, [targetDate])

  return (
    <div className="flex items-end gap-2 mb-4">
      {[['d','Days'],['h','Hrs'],['m','Min'],['s','Sec']].map(([k, label]) => (
        <div key={k} className="flex items-end gap-1">
          <div className="text-center">
            <span className="font-orbitron font-black text-2xl block"
              style={{ background:'linear-gradient(135deg,#ff0099,#b200ff)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
              {String(timeLeft[k as keyof typeof timeLeft]).padStart(2,'0')}
            </span>
            <span className="font-mono text-[0.6rem] tracking-wider uppercase text-white/25">{label}</span>
          </div>
          {k !== 's' && <span className="font-orbitron text-2xl text-[#ff0099]/30 mb-1">:</span>}
        </div>
      ))}
    </div>
  )
}

const BANNER_STYLES = [
  { bg: 'linear-gradient(135deg, rgba(0,100,200,0.3), rgba(178,0,255,0.2))', border: 'rgba(0,212,255,0.3)' },
  { bg: 'linear-gradient(135deg, rgba(255,0,153,0.2), rgba(178,0,255,0.2))', border: 'rgba(255,0,153,0.3)' },
  { bg: 'linear-gradient(135deg, rgba(0,255,136,0.1), rgba(0,212,255,0.2))', border: 'rgba(0,255,136,0.3)' },
]
const ICONS: Record<string, string> = { bowling:'🏆', vr:'🥽', arcade:'🕹', general:'🎮' }

export function EventsSection({ events }: { events: GameEvent[] }) {
  return (
    <section id="events" className="relative py-24 px-6"
      style={{ background:'radial-gradient(ellipse 50% 60% at 50% 30%, rgba(255,0,153,0.07), transparent)' }}>
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}>
          <div className="section-tag">🎉 UPCOMING EVENTS</div>
          <h2 className="font-orbitron font-black leading-tight mb-4" style={{ fontSize:'clamp(2rem,5vw,3.5rem)' }}>
            <span className="grad-headline-2">Events &</span><br />Tournaments
          </h2>
          <p className="text-white/45 text-lg mb-12">Epic gaming events every week. Compete, win prizes, become a legend.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {events.map((ev, i) => {
            const style = BANNER_STYLES[i % BANNER_STYLES.length]
            return (
              <motion.div key={ev.id} initial={{ opacity:0, y:40 }} whileInView={{ opacity:1, y:0 }}
                viewport={{ once:true }} transition={{ delay:i*0.1 }}
                className="rounded-2xl overflow-hidden cursor-pointer group"
                style={{ border:`1px solid ${style.border}` }}
                whileHover={{ y:-8, boxShadow:`0 20px 50px ${style.border}` }}
              >
                {/* Banner */}
                <div className="h-36 flex items-center justify-center text-6xl relative overflow-hidden" style={{ background: style.bg }}>
                  <motion.div animate={{ y:[0,-8,0] }} transition={{ duration:3, repeat:Infinity }}>
                    {ICONS[ev.category] || '🎮'}
                  </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40" />
                </div>

                <div className="p-5">
                  <div className="font-mono text-[0.62rem] tracking-widest uppercase text-[#ff0099] mb-2 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ff0099] animate-pulse" />
                    {ev.category.toUpperCase()} TOURNAMENT
                  </div>
                  <h3 className="font-orbitron font-bold text-base text-white mb-1.5">{ev.title}</h3>
                  <p className="text-white/40 text-sm mb-3">
                    📅 {format(new Date(ev.event_date), 'MMMM d, yyyy · h:mm a')}
                  </p>

                  <Countdown targetDate={ev.event_date} />

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="font-mono text-[0.6rem] text-white/25 tracking-wider">PRIZE POOL</div>
                      <div className="font-orbitron font-bold text-sm text-[#ffd700]">{ev.prize_pool || 'TBA'}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-[0.6rem] text-white/25 tracking-wider">ENTRY FEE</div>
                      <div className="font-orbitron font-bold text-sm text-[#00ff88]">₹{ev.entry_fee}</div>
                    </div>
                  </div>

                  {/* Participant bar */}
                  <div className="mb-4">
                    <div className="flex justify-between font-mono text-[0.6rem] text-white/30 mb-1.5">
                      <span>{ev.current_participants} Registered</span>
                      <span>{ev.max_participants} Max</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-1000"
                        style={{ width:`${(ev.current_participants/ev.max_participants)*100}%`, background:'linear-gradient(90deg,#ff0099,#b200ff)' }} />
                    </div>
                  </div>

                  <button className="w-full font-orbitron text-xs font-bold tracking-wider py-2.5 rounded border border-[#ff0099]/30 text-[#ff0099] hover:bg-[#ff0099]/10 hover:border-[#ff0099] transition-all">
                    REGISTER NOW →
                  </button>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
