'use client'
import { motion } from 'framer-motion'

const AMENITIES = [
  { icon:'🌬', name:'AC COMFORT',     desc:'Fully air-conditioned gaming environment.' },
  { icon:'🍔', name:'FOOD COURT',     desc:'Burgers, shakes, and gaming fuel.' },
  { icon:'🅿️', name:'FREE PARKING',  desc:'Dedicated parking for 100+ vehicles.' },
  { icon:'📶', name:'GIGABIT WIFI',   desc:'Ultra-fast gaming-grade internet.' },
  { icon:'🎧', name:'PRO HEADSETS',   desc:'Studio-grade audio for VR & gaming.' },
  { icon:'🛋', name:'LOUNGE ZONE',    desc:'Chill between rounds in plush seating.' },
  { icon:'🎂', name:'PARTY ROOMS',    desc:'Private event spaces for groups.' },
  { icon:'📱', name:'MOBILE APP',     desc:'Book, track XP, and check leaderboard.' },
]

export function AmenitiesSection() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}>
          <div className="section-tag">✨ THE HUB EXPERIENCE</div>
          <h2 className="font-orbitron font-black leading-tight mb-10" style={{ fontSize:'clamp(2rem,5vw,3.5rem)' }}>
            <span className="grad-headline-2">Everything</span><br />You Need
          </h2>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {AMENITIES.map((a, i) => (
            <motion.div key={a.name} initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }}
              viewport={{ once:true }} transition={{ delay:i*0.06 }}
              className="p-6 rounded-xl border border-[#00d4ff]/10 bg-[#00d4ff]/03 text-center hover:border-[#00d4ff]/35 hover:bg-[#00d4ff]/07 hover:-translate-y-2 transition-all duration-300 cursor-default group">
              <span className="text-4xl block mb-3 group-hover:scale-110 transition-transform" style={{ filter:'drop-shadow(0 0 8px rgba(0,212,255,0.5))' }}>{a.icon}</span>
              <div className="font-orbitron font-bold text-xs tracking-wider text-white mb-1.5">{a.name}</div>
              <div className="text-white/35 text-xs leading-relaxed">{a.desc}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
