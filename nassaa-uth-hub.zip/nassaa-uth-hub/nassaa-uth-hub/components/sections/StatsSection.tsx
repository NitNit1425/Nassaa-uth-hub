'use client'
import { useRef, useEffect } from 'react'
import { motion, useInView } from 'framer-motion'
import { gsap } from 'gsap'

const STATS = [
  { val:50,   suffix:'+', label:'Gaming Titles',  color:'#00d4ff' },
  { val:1200, suffix:'+', label:'Happy Players',  color:'#b200ff' },
  { val:8,    suffix:'',  label:'VR Zones',       color:'#ff0099' },
  { val:12,   suffix:'',  label:'Bowling Lanes',  color:'#00ff88' },
  { val:99,   suffix:'%', label:'Satisfaction',   color:'#ffd700' },
]

export function StatsSection() {
  const ref   = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once:true, margin:'-100px' })

  useEffect(() => {
    if (!inView || !ref.current) return
    ref.current.querySelectorAll('[data-target]').forEach(el => {
      const target = parseInt(el.getAttribute('data-target') || '0')
      gsap.fromTo(el, { textContent: 0 }, {
        textContent: target, duration:2.5, ease:'power2.out',
        snap:{ textContent:1 },
        onUpdate() { el.textContent = Math.ceil(parseFloat(el.textContent||'0')).toLocaleString() }
      })
    })
  }, [inView])

  return (
    <section ref={ref} className="py-16 px-6 bg-black/20">
      <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-6">
        {STATS.map((s, i) => (
          <motion.div key={s.label} className="text-center py-6 px-4 rounded-xl border border-white/5 bg-white/[0.02]"
            initial={{ opacity:0, scale:0.8 }} whileInView={{ opacity:1, scale:1 }} viewport={{ once:true }}
            transition={{ delay:i*0.1, type:'spring', stiffness:120 }}>
            <div className="font-orbitron font-black text-4xl mb-1" style={{ color:s.color, textShadow:`0 0 20px ${s.color}60` }}>
              <span data-target={s.val}>{s.val}</span>{s.suffix}
            </div>
            <div className="font-mono text-[0.68rem] tracking-widest uppercase text-white/30">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
