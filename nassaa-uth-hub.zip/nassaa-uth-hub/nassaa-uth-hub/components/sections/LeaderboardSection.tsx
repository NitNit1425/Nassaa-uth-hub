'use client'
import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/supabase/client'
import type { LeaderboardEntry } from '@/types/supabase'
import { Crown, TrendingUp } from 'lucide-react'

const MEDAL = ['🥇','🥈','🥉']
const RANK_STYLES: Record<number, string> = {
  0: 'border-[#ffd700]/30 bg-[#ffd700]/05',
  1: 'border-[#c0c0c0]/20 bg-[#c0c0c0]/04',
  2: 'border-[#cd7f32]/20 bg-[#cd7f32]/04',
}
const BADGE_COLORS: Record<string, string> = {
  LEGEND:  'bg-[#ffd700]/10 text-[#ffd700] border-[#ffd700]/30',
  PRO:     'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30',
  VETERAN: 'bg-[#b200ff]/10 text-[#d97aff] border-[#b200ff]/30',
  SKILLED: 'bg-[#00ff88]/10 text-[#00ff88] border-[#00ff88]/30',
}

export function LeaderboardSection({ initialData }: { initialData: LeaderboardEntry[] }) {
  const [data, setData]     = useState(initialData)
  const [updated, setUpdated] = useState<string | null>(null)
  const supabase = createClient()

  useEffect(() => {
    const channel = supabase
      .channel('leaderboard-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leaderboard' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setData((prev) => {
            const next = [payload.new as LeaderboardEntry, ...prev]
              .sort((a, b) => b.score - a.score)
              .slice(0, 10)
            return next
          })
          setUpdated((payload.new as LeaderboardEntry).id)
          setTimeout(() => setUpdated(null), 2000)
        }
        if (payload.eventType === 'UPDATE') {
          setData((prev) => {
            const next = prev.map((e) => e.id === payload.new.id ? { ...e, ...payload.new } as LeaderboardEntry : e)
              .sort((a, b) => b.score - a.score)
            return next
          })
          setUpdated(payload.new.id)
          setTimeout(() => setUpdated(null), 2000)
        }
      })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [])

  return (
    <section id="leaderboard" className="relative py-24 px-6"
      style={{ background:'radial-gradient(ellipse 60% 60% at 70% 50%, rgba(0,212,255,0.07), transparent)' }}>
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}>
          <div className="section-tag">🏆 HALL OF LEGENDS</div>
          <h2 className="font-orbitron font-black leading-tight mb-4" style={{ fontSize:'clamp(2rem,5vw,3.5rem)' }}>
            <span className="grad-headline-2">Live</span> Leaderboard
          </h2>
          <p className="text-white/45 text-lg mb-10">The top players at Nassaa Uth Hub. Real-time updates powered by Supabase.</p>
        </motion.div>

        {/* Header */}
        <div className="grid grid-cols-[56px_1fr_120px_100px] gap-3 px-5 mb-3 font-mono text-[0.68rem] tracking-widest uppercase text-white/25 border-b border-white/5 pb-3">
          <div>Rank</div><div>Player</div><div>Score</div><div>XP</div>
        </div>

        <div className="flex flex-col gap-2">
          <AnimatePresence mode="popLayout">
            {data.map((entry, i) => (
              <motion.div
                key={entry.id}
                layout
                initial={{ opacity:0, x:-20 }}
                animate={{ opacity:1, x:0 }}
                exit={{ opacity:0, x:20 }}
                transition={{ duration:0.4, ease:[0.23,1,0.32,1] }}
                className={`grid grid-cols-[56px_1fr_120px_100px] gap-3 items-center px-5 py-4 rounded-xl border lb-row-anim transition-all ${
                  updated === entry.id ? 'border-[#00d4ff]/60 bg-[#00d4ff]/10 shadow-neon-blue' :
                  RANK_STYLES[i] || 'border-white/5 bg-white/[0.02]'
                } hover:border-[#00d4ff]/25 hover:bg-[#00d4ff]/05`}
              >
                {/* Rank */}
                <div className="font-orbitron font-black text-lg text-center">
                  {i < 3 ? <span style={{ filter:`drop-shadow(0 0 8px ${['#ffd700','#c0c0c0','#cd7f32'][i]})` }}>{MEDAL[i]}</span>
                          : <span className="text-white/25">#{i+1}</span>}
                </div>

                {/* Player */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full border border-[#00d4ff]/25 bg-[#00d4ff]/08 flex items-center justify-center text-lg flex-shrink-0">
                    {entry.player_avatar || '👤'}
                  </div>
                  <div className="min-w-0">
                    <div className="font-rajdhani font-semibold text-white truncate">{entry.player_name}</div>
                    {entry.badge && (
                      <span className={`font-mono text-[0.55rem] tracking-wider px-1.5 py-0.5 rounded border ${BADGE_COLORS[entry.badge] || BADGE_COLORS.SKILLED}`}>
                        {entry.badge}
                      </span>
                    )}
                  </div>
                </div>

                {/* Score */}
                <div className="font-orbitron font-bold text-sm"
                  style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
                  {entry.score.toLocaleString()}
                </div>

                {/* XP */}
                <div>
                  <div className="font-mono text-xs text-[#00ff88] mb-1">{entry.xp_earned.toLocaleString()} XP</div>
                  <div className="h-1 bg-white/5 rounded-full overflow-hidden w-20">
                    <div className="xp-bar-fill" style={{ width: `${Math.min(100, (entry.xp_earned / 10000) * 100)}%` }} />
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <motion.div className="flex items-center gap-2 mt-5 text-[#00ff88]/50 font-mono text-xs"
          animate={{ opacity:[0.5,1,0.5] }} transition={{ duration:2, repeat:Infinity }}>
          <div className="w-1.5 h-1.5 rounded-full bg-[#00ff88]" />
          LIVE — Updates in real-time via Supabase Realtime
        </motion.div>
      </div>
    </section>
  )
}
