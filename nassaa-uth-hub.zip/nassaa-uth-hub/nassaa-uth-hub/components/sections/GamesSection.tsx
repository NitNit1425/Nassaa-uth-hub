'use client'
import { useRef } from 'react'
import Link from 'next/link'
import { motion, useInView } from 'framer-motion'
import { useBookingStore } from '@/store'
import { useRouter } from 'next/navigation'
import type { Game } from '@/types/supabase'

const BADGE_COLORS: Record<string, string> = {
  blue:   'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30',
  pink:   'bg-[#ff0099]/10 text-[#ff0099] border-[#ff0099]/30',
  purple: 'bg-[#b200ff]/10 text-[#d97aff] border-[#b200ff]/30',
  green:  'bg-[#00ff88]/10 text-[#00ff88] border-[#00ff88]/30',
}

function GameCard({ game, index }: { game: Game; index: number }) {
  const cardRef   = useRef<HTMLDivElement>(null)
  const router    = useRouter()
  const setGame   = useBookingStore((s) => s.setGame)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = cardRef.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width  - 0.5
    const y = (e.clientY - rect.top)  / rect.height - 0.5
    el.style.transform = `perspective(800px) rotateX(${-y*12}deg) rotateY(${x*12}deg) translateY(-10px) scale(1.03)`
  }
  const handleMouseLeave = () => {
    if (cardRef.current) cardRef.current.style.transform = ''
  }
  const handleBook = () => {
    setGame(game)
    router.push('/booking')
  }

  return (
    <motion.div
      initial={{ opacity:0, y:50 }}
      whileInView={{ opacity:1, y:0 }}
      viewport={{ once:true, margin:'-50px' }}
      transition={{ delay: index * 0.08, duration:0.6, ease:[0.23,1,0.32,1] }}
    >
      <div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="game-card-wrap relative rounded-xl p-6 cursor-pointer group"
        style={{
          background: 'rgba(0,180,255,0.04)',
          border: '1px solid rgba(0,212,255,0.15)',
          transition: 'transform 0.4s cubic-bezier(0.23,1,0.32,1), box-shadow 0.4s, border-color 0.3s',
        }}
      >
        {/* Hover glow bg */}
        <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-400"
          style={{ background:'radial-gradient(circle at 50% 0%, rgba(0,212,255,0.1), transparent 60%)' }} />

        {/* Featured badge */}
        {game.is_featured && (
          <div className="absolute top-3 right-3 font-mono text-[0.6rem] tracking-widest bg-[#ffd700]/10 text-[#ffd700] border border-[#ffd700]/30 px-2 py-0.5 rounded">
            ⭐ FEATURED
          </div>
        )}

        {/* Icon */}
        <div className="text-5xl mb-4 block transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6"
          style={{ filter:'drop-shadow(0 0 12px rgba(0,212,255,0.6))' }}>
          {game.icon}
        </div>

        <h3 className="font-orbitron font-bold text-[1rem] tracking-wider text-white mb-2">{game.name}</h3>
        <p className="text-white/45 text-sm leading-relaxed mb-4 line-clamp-2">{game.short_desc}</p>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="font-orbitron font-black text-xl"
              style={{ background:'linear-gradient(135deg,#00ff88,#00d4ff)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
              ₹{game.price}
            </span>
            <span className="text-white/35 text-xs ml-1">/{game.duration_minutes}min</span>
          </div>
          {game.badge && (
            <span className={`font-mono text-[0.6rem] tracking-wider px-2 py-0.5 rounded border ${BADGE_COLORS[game.badge_color || 'blue']}`}>
              {game.badge}
            </span>
          )}
        </div>

        <button
          onClick={handleBook}
          className="w-full font-orbitron text-xs font-bold tracking-widest py-2.5 rounded border border-[#00d4ff]/30 text-[#00d4ff] hover:bg-[#00d4ff]/15 hover:border-[#00d4ff] transition-all"
        >
          BOOK NOW →
        </button>
      </div>
    </motion.div>
  )
}

export function GamesSection({ games }: { games: Game[] }) {
  return (
    <section id="games" className="relative py-24 px-6"
      style={{ background:'radial-gradient(ellipse 70% 50% at 50% 50%, rgba(0,80,160,0.1), transparent)' }}>
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}>
          <div className="section-tag">🎮 GAME ZONE</div>
          <h2 className="font-orbitron font-black leading-tight mb-4" style={{ fontSize:'clamp(2rem,5vw,3.5rem)' }}>
            <span className="grad-headline-2">Choose Your</span>
            <br />Adventure
          </h2>
          <p className="text-white/45 text-lg leading-relaxed max-w-lg mb-12">
            From high-octane VR battles to classic bowling — every game is an experience engineered to thrill.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {games.map((g, i) => <GameCard key={g.id} game={g} index={i} />)}
        </div>
      </div>
    </section>
  )
}
