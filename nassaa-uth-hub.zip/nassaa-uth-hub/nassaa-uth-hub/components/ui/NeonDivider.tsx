export function NeonDivider() {
  return (
    <div className="neon-divider mx-0" />
  )
}
