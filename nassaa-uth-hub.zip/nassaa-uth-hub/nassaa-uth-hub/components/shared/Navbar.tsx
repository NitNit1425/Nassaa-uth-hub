'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuthStore, useUIStore } from '@/store'
import { createClient } from '@/supabase/client'
import { Menu, X, Zap, LogOut, User, LayoutDashboard } from 'lucide-react'

const NAV_LINKS = [
  { href: '/#games',       label: 'Games' },
  { href: '/booking',      label: 'Book Slot' },
  { href: '/#leaderboard', label: 'Leaderboard' },
  { href: '/#events',      label: 'Events' },
  { href: '/#contact',     label: 'Location' },
]

export function Navbar() {
  const [scrolled, setScrolled]   = useState(false)
  const [menuOpen, setMenuOpen]   = useState(false)
  const { user }   = useAuthStore()
  const router     = useRouter()
  const pathname   = usePathname()
  const supabase   = createClient()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const signOut = async () => {
    await supabase.auth.signOut()
    router.push('/')
  }

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-[500] transition-all duration-300 ${
        scrolled ? 'py-3 bg-[rgba(3,5,8,0.85)] backdrop-blur-xl border-b border-[rgba(0,212,255,0.12)] shadow-[0_4px_40px_rgba(0,0,0,0.4)]'
                 : 'py-5 bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.23,1,0.32,1] }}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="font-orbitron font-black text-lg tracking-widest" style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          ⚡ NASSAA UTH HUB
        </Link>

        {/* Desktop Links */}
        <ul className="hidden lg:flex items-center gap-8">
          {NAV_LINKS.map((l) => (
            <li key={l.href}>
              <Link href={l.href} className="font-rajdhani font-semibold text-sm tracking-widest uppercase text-white/50 hover:text-[#00d4ff] transition-colors relative group">
                {l.label}
                <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#00d4ff] transition-all duration-300 group-hover:w-full" />
              </Link>
            </li>
          ))}
        </ul>

        {/* CTA + Auth */}
        <div className="hidden lg:flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3">
              {user.role === 'admin' && (
                <Link href="/admin" className="flex items-center gap-1.5 text-xs font-orbitron tracking-wider text-[#00ff88] border border-[#00ff88]/30 px-3 py-2 rounded hover:bg-[#00ff88]/10 transition-all">
                  <LayoutDashboard size={13} /> ADMIN
                </Link>
              )}
              <Link href="/profile" className="flex items-center gap-2 text-sm text-white/70 hover:text-white transition-colors">
                <div className="w-8 h-8 rounded-full border border-[#00d4ff]/30 bg-[#00d4ff]/10 flex items-center justify-center text-base">
                  {user.avatar_url ? <img src={user.avatar_url} className="w-full h-full rounded-full object-cover" /> : '👤'}
                </div>
                <span className="font-rajdhani font-semibold">{user.full_name.split(' ')[0]}</span>
              </Link>
              <button onClick={signOut} className="p-2 text-white/30 hover:text-[#ff0099] transition-colors"><LogOut size={16} /></button>
            </div>
          ) : (
            <>
              <Link href="/auth/login" className="font-orbitron text-xs font-bold tracking-wider text-[#00d4ff] border border-[#00d4ff]/40 px-4 py-2 rounded hover:bg-[#00d4ff]/10 transition-all">
                LOGIN
              </Link>
              <Link href="/booking" className="font-orbitron text-xs font-bold tracking-wider text-white px-4 py-2 rounded magnetic-btn" style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}>
                BOOK SLOT
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu */}
        <button className="lg:hidden text-[#00d4ff]" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="lg:hidden fixed inset-0 top-16 bg-[rgba(3,5,8,0.97)] backdrop-blur-2xl z-40 flex flex-col items-center justify-center gap-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            {NAV_LINKS.map((l, i) => (
              <motion.div key={l.href} initial={{ opacity:0,x:-30 }} animate={{ opacity:1,x:0 }} transition={{ delay: i*0.07 }}>
                <Link href={l.href} onClick={() => setMenuOpen(false)} className="font-orbitron font-bold text-2xl tracking-widest text-white/80 hover:text-[#00d4ff] transition-colors">
                  {l.label}
                </Link>
              </motion.div>
            ))}
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:0.4 }}>
              <Link href="/booking" onClick={() => setMenuOpen(false)} className="font-orbitron text-sm font-black tracking-wider text-white px-8 py-3 rounded" style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}>
                BOOK YOUR SLOT
              </Link>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}
