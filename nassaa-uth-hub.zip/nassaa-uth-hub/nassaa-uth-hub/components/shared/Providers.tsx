'use client'
import { useEffect, useRef } from 'react'
import { useUIStore, useAuthStore } from '@/store'
import { createClient } from '@/supabase/client'

export function Providers({ children }: { children: React.ReactNode }) {
  const setLoading = useUIStore((s) => s.setLoading)
  const setUser    = useAuthStore((s) => s.setUser)
  const supabase   = createClient()
  const initiated  = useRef(false)

  useEffect(() => {
    if (initiated.current) return
    initiated.current = true

    // Load session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session) {
        const { data } = await supabase.from('users').select('*').eq('id', session.user.id).single()
        if (data) setUser(data)
      }
      setTimeout(() => setLoading(false), 2800)
    })

    // Listen for auth changes
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (session && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED')) {
        const { data } = await supabase.from('users').select('*').eq('id', session.user.id).single()
        if (data) setUser(data)
      } else if (event === 'SIGNED_OUT') {
        setUser(null)
      }
    })
  }, [])

  return <>{children}</>
}
