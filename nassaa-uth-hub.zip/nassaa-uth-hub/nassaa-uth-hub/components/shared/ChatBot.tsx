'use client'
import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Send, MessageCircle, Loader2 } from 'lucide-react'

type Msg = { role: 'bot' | 'user'; text: string }

const FAQ: Record<string, string> = {
  book:       '📅 Head to our Booking section! Choose your game, pick a slot, and confirm instantly.',
  price:      '💰 Bowling: ₹250 | VR: ₹350/30min | Arcade: ₹200/hr | Laser Tag: ₹400/session',
  location:   '📍 Besant Nagar, Chennai 600090. Near Elliot\'s Beach!',
  timing:     '⏰ Open every day, 10AM – 11PM. Arrive early on weekends!',
  vr:         '🥽 VR Zone has Boxing, Racing, Full Showdown & more. All headsets sanitized after every session.',
  bowling:    '🎳 12 auto-scoring neon lanes! Walk-in or book in advance.',
  parking:    '🅿️ Free parking for 100+ vehicles.',
  party:      '🎂 Private party rooms available for events! Email: hello@nassaauthhub.in',
  cancel:     '🔄 Free cancellation up to 2 hours before your slot. No questions asked.',
  payment:    '💳 We accept UPI, cards, net banking via Razorpay. Secure & instant.',
}

export function ChatBot() {
  const [open, setOpen]     = useState(false)
  const [msgs, setMsgs]     = useState<Msg[]>([
    { role:'bot', text:'Hey gamer! 👾 I\'m your Nassaa Uth Hub AI. Ask me about booking, games, location, or anything!' }
  ])
  const [input, setInput]   = useState('')
  const [typing, setTyping] = useState(false)
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior:'smooth' }) }, [msgs, typing])

  const reply = (text: string) => {
    const lower = text.toLowerCase()
    for (const [key, ans] of Object.entries(FAQ)) {
      if (lower.includes(key)) return ans
    }
    return '🤖 I\'m not sure about that! Try asking about booking, pricing, location, VR, or bowling. Or call us at +91 98765 43210.'
  }

  const send = () => {
    if (!input.trim()) return
    const msg = input.trim()
    setMsgs((m) => [...m, { role:'user', text: msg }])
    setInput('')
    setTyping(true)
    setTimeout(() => {
      setTyping(false)
      setMsgs((m) => [...m, { role:'bot', text: reply(msg) }])
    }, 900)
  }

  return (
    <>
      {/* Bubble */}
      <motion.button
        className="fixed bottom-6 right-6 z-[2000] w-14 h-14 rounded-full flex items-center justify-center text-white"
        style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)', boxShadow:'0 0 30px rgba(0,212,255,0.5)' }}
        onClick={() => setOpen(!open)}
        whileHover={{ scale:1.1 }}
        whileTap={{ scale:0.9 }}
        animate={{ boxShadow:['0 0 30px rgba(0,212,255,0.5)', '0 0 50px rgba(178,0,255,0.6)', '0 0 30px rgba(0,212,255,0.5)'] }}
        transition={{ duration:3, repeat:Infinity }}
      >
        <AnimatePresence mode="wait">
          {open ? <X key="x" size={22} /> : <MessageCircle key="mc" size={22} />}
        </AnimatePresence>
      </motion.button>

      {/* Window */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed bottom-24 right-6 z-[2000] w-[320px] rounded-2xl overflow-hidden flex flex-col"
            style={{ background:'rgba(3,8,20,0.97)', border:'1px solid rgba(0,212,255,0.25)', boxShadow:'0 20px 60px rgba(0,0,0,0.5), 0 0 40px rgba(0,212,255,0.1)', maxHeight:480 }}
            initial={{ opacity:0, y:20, scale:0.95 }}
            animate={{ opacity:1, y:0, scale:1 }}
            exit={{ opacity:0, y:20, scale:0.95 }}
          >
            {/* Header */}
            <div className="px-4 py-3.5 border-b border-[#00d4ff]/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-base"
                style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}>⚡</div>
              <div>
                <div className="font-orbitron text-xs font-bold text-white">NUH AI ASSISTANT</div>
                <div className="flex items-center gap-1.5 font-mono text-[0.6rem] text-[#00ff88]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-pulse" />
                  Online now
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3" style={{ maxHeight:300 }}>
              {msgs.map((m, i) => (
                <motion.div key={i} initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }}
                  className={`max-w-[85%] text-sm leading-relaxed px-3.5 py-2.5 rounded-xl ${
                    m.role === 'bot'
                      ? 'self-start bg-[#00d4ff]/08 border border-[#00d4ff]/15 rounded-tl-sm'
                      : 'self-end bg-gradient-to-br from-[#00d4ff]/20 to-[#b200ff]/15 border border-[#00d4ff]/20 rounded-tr-sm'
                  }`}>{m.text}</motion.div>
              ))}
              {typing && (
                <div className="self-start flex gap-1.5 items-center px-3.5 py-2.5 bg-[#00d4ff]/08 border border-[#00d4ff]/15 rounded-xl rounded-tl-sm">
                  {[0,1,2].map(i => (
                    <motion.div key={i} className="w-2 h-2 rounded-full bg-[#00d4ff]"
                      animate={{ scale:[0.8,1,0.8], opacity:[0.3,1,0.3] }}
                      transition={{ duration:1.2, delay:i*0.2, repeat:Infinity }} />
                  ))}
                </div>
              )}
              <div ref={endRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t border-[#00d4ff]/10 flex gap-2">
              <input
                className="flex-1 bg-[#00d4ff]/06 border border-[#00d4ff]/20 rounded-lg px-3 py-2 text-sm text-white placeholder-white/25 outline-none focus:border-[#00d4ff]/50 font-rajdhani"
                placeholder="Ask me anything..."
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && send()}
              />
              <button onClick={send} className="w-9 h-9 rounded-lg flex items-center justify-center text-white transition-all hover:scale-110"
                style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}>
                <Send size={14} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
