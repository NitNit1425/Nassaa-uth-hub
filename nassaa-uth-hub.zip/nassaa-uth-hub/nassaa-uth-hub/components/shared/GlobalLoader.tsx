'use client'
import { useEffect, useState } from 'react'
import { useUIStore } from '@/store'
import { motion, AnimatePresence } from 'framer-motion'

export function GlobalLoader() {
  const isLoading = useUIStore((s) => s.isLoading)
  const [pct, setPct] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setPct((p) => {
        const next = Math.min(p + Math.random() * 18, 99)
        if (p >= 99) clearInterval(interval)
        return next
      })
    }, 100)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!isLoading) setPct(100)
  }, [isLoading])

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          className="fixed inset-0 bg-black z-[99999] flex flex-col items-center justify-center gap-6"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Glitch logo */}
          <motion.div
            className="font-orbitron font-black text-4xl md:text-6xl tracking-widest animate-glitch"
            style={{
              background: 'linear-gradient(135deg,#00d4ff,#b200ff,#ff0099)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
          >
            NASSAA UTH HUB
          </motion.div>

          <motion.div
            className="font-mono text-sm tracking-[0.35em] text-[#00d4ff] opacity-70"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.7, 0] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            ▶ INITIALIZING GAME WORLD...
          </motion.div>

          {/* Loading bar */}
          <div className="w-72 h-[3px] bg-white/5 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: 'linear-gradient(90deg,#00d4ff,#b200ff,#ff0099)', boxShadow: '0 0 12px #00d4ff' }}
              initial={{ width: '0%' }}
              animate={{ width: `${pct}%` }}
              transition={{ ease: 'easeOut' }}
            />
          </div>
          <div className="font-mono text-sm text-[#00d4ff] tracking-widest">{Math.floor(pct)}%</div>

          {/* Scan line */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00d4ff]/30 to-transparent"
              animate={{ top: ['-5%', '105%'] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
