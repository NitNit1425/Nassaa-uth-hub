'use client'
import { useEffect, useRef } from 'react'

export function CustomCursor() {
  const ringRef = useRef<HTMLDivElement>(null)
  const dotRef  = useRef<HTMLDivElement>(null)
  const pos     = useRef({ x: 0, y: 0, cx: 0, cy: 0 })
  const raf     = useRef<number>(0)

  useEffect(() => {
    const onMove = (e: MouseEvent) => { pos.current.x = e.clientX; pos.current.y = e.clientY }
    const animate = () => {
      const { x, y, cx, cy } = pos.current
      const nx = cx + (x - cx) * 0.15
      const ny = cy + (y - cy) * 0.15
      pos.current.cx = nx; pos.current.cy = ny
      if (dotRef.current)  { dotRef.current.style.left = x + 'px';  dotRef.current.style.top = y + 'px' }
      if (ringRef.current) { ringRef.current.style.left = nx + 'px'; ringRef.current.style.top = ny + 'px' }
      raf.current = requestAnimationFrame(animate)
    }
    const onEnter = () => ringRef.current?.classList.add('hovering')
    const onLeave = () => ringRef.current?.classList.remove('hovering')

    document.addEventListener('mousemove', onMove)
    document.querySelectorAll('a, button, [role=button], .game-card-wrap').forEach(el => {
      el.addEventListener('mouseenter', onEnter)
      el.addEventListener('mouseleave', onLeave)
    })
    raf.current = requestAnimationFrame(animate)

    return () => {
      document.removeEventListener('mousemove', onMove)
      cancelAnimationFrame(raf.current)
    }
  }, [])

  return (
    <>
      <div ref={ringRef}  className="cursor-ring hidden md:block" />
      <div ref={dotRef}   className="cursor-dot  hidden md:block" />
    </>
  )
}
