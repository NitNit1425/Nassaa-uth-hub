# ⚡ NASSAA UTH HUB — Full Stack Gaming Website

> **Cinematic, futuristic, immersive gaming hub website built with Next.js 14 + Supabase**

📍 Besant Nagar, Chennai

---

## 🚀 Tech Stack

| Layer         | Technology                              |
|---------------|----------------------------------------|
| **Frontend**  | Next.js 14 (App Router) + TypeScript   |
| **Styling**   | Tailwind CSS + Custom Neon Design System|
| **Animation** | Framer Motion + GSAP                   |
| **3D/WebGL**  | React Three Fiber (Three.js)           |
| **State**     | Zustand (persist)                      |
| **Backend**   | Supabase (PostgreSQL + Auth + Realtime)|
| **Payments**  | Razorpay Webhooks                      |
| **Charts**    | Recharts                               |
| **Fonts**     | Orbitron + Rajdhani + Share Tech Mono  |

---

## 📁 Project Structure

```
nassaa-uth-hub/
├── app/
│   ├── page.tsx              — Home page (SSR, fetches from Supabase)
│   ├── layout.tsx            — Root layout, fonts, global providers
│   ├── booking/page.tsx      — 5-step animated booking flow
│   ├── auth/login/page.tsx   — Login (email + Google OAuth)
│   ├── auth/register/page.tsx— Registration
│   ├── auth/callback/route.ts— OAuth callback handler
│   ├── profile/page.tsx      — User profile + booking history + XP
│   ├── admin/page.tsx        — Admin dashboard (charts, tables, export)
│   └── api/
│       ├── bookings/route.ts — Booking CRUD API
│       └── webhooks/razorpay/— Payment webhook handler
├── components/
│   ├── shared/
│   │   ├── Providers.tsx     — Auth session provider
│   │   ├── GlobalLoader.tsx  — Cinematic loader with glitch animation
│   │   ├── CustomCursor.tsx  — Gaming crosshair cursor
│   │   ├── ParticleCanvas.tsx— Interactive particle background
│   │   ├── Navbar.tsx        — Glassmorphism nav + mobile menu
│   │   └── ChatBot.tsx       — AI chatbot with animated typing
│   ├── sections/
│   │   ├── HeroSection.tsx   — Three.js 3D bowling ball + letter animation
│   │   ├── GamesSection.tsx  — 3D tilt game cards
│   │   ├── StatsSection.tsx  — GSAP animated counters
│   │   ├── LeaderboardSection.tsx — Supabase Realtime live scores
│   │   ├── EventsSection.tsx — Countdown timers + registration
│   │   ├── AmenitiesSection.tsx
│   │   └── ContactSection.tsx
│   └── ui/NeonDivider.tsx
├── supabase/
│   ├── client.ts             — Browser Supabase client
│   ├── server.ts             — Server + Admin Supabase clients
│   └── migrations/001_initial_schema.sql — Full DB schema
├── store/index.ts            — Zustand (auth + booking + UI state)
├── types/supabase.ts         — Full TypeScript types for DB
├── middleware.ts             — Auth guard + admin protection
└── .env.local.example        — Environment variables template
```

---

## 🛠 Setup Instructions

### 1. Clone & Install
```bash
git clone <your-repo>
cd nassaa-uth-hub
npm install
```

### 2. Supabase Setup
1. Create a project at [supabase.com](https://supabase.com)
2. Run `supabase/migrations/001_initial_schema.sql` in the SQL editor
3. Enable Google OAuth in Supabase Auth → Providers
4. Copy your project URL and keys

### 3. Environment Variables
```bash
cp .env.local.example .env.local
# Fill in your values
```

### 4. Run Development Server
```bash
npm run dev
# → http://localhost:3000
```

### 5. Deploy to Vercel
```bash
vercel deploy --prod
```

---

## 🗄️ Database Schema

```
users          — Profiles, XP, roles
games          — All game listings (seeded)
slots          — Time slots with real-time locking
bookings       — Booking records + payment status
leaderboard    — Scores with Realtime updates
events         — Tournaments and events
booking_details— Denormalized view for admin/profile
```

---

## ⚡ Key Features

### 🎬 Cinematic Animations
- Neon glitch loader with percentage counter
- Gaming crosshair custom cursor with lag effect
- Interactive particle network reacting to mouse
- Three.js 3D bowling ball in hero (WebGL)
- GSAP animated stat counters
- Framer Motion stagger reveals
- 3D CSS tilt on game cards

### 🔐 Authentication
- Email/password signup + login
- Google OAuth
- JWT sessions via Supabase Auth
- Role-based access (user/admin)
- Protected routes via middleware

### ⚡ Real-Time Features
- **Live Leaderboard** — Supabase Realtime subscriptions
- **Slot Locking** — 5-minute hold preventing double-booking
- **Live Slot Status** — Realtime slot availability updates
- **Booking Updates** — Live payment confirmation

### 📊 Admin Dashboard
- Revenue area chart (Recharts)
- Daily bookings bar chart
- Booking table with status badges
- CSV export
- Animated metric cards

### 💳 Payments (Razorpay)
- Secure payment intent creation
- Webhook verification with HMAC signature
- Auto-confirm booking on payment capture
- Slot permanently locked after payment

---

## 🎨 Design System

```css
/* Neon Color Palette */
--neon-blue:   #00d4ff  /* Primary */
--neon-purple: #b200ff  /* Secondary */
--neon-pink:   #ff0099  /* Accent */
--neon-green:  #00ff88  /* Success */
--neon-gold:   #ffd700  /* Premium */

/* Fonts */
Orbitron      — Headlines, logo, stats
Rajdhani      — Body text, UI
Share Tech Mono — Labels, badges, codes
```

---

## 📱 Pages

| Route              | Description                         |
|--------------------|-------------------------------------|
| `/`                | Home (hero, games, leaderboard, events)|
| `/booking`         | 5-step animated booking flow        |
| `/auth/login`      | Sign in (email + Google)            |
| `/auth/register`   | Create account                      |
| `/profile`         | User profile, XP, booking history   |
| `/admin`           | Admin dashboard (admin-only)        |

---

## 🚦 Performance Notes
- All heavy animations use `transform` and `opacity` (GPU accelerated)
- Three.js scene loaded with React Suspense
- Images use Next.js `<Image>` with lazy loading
- Supabase queries run server-side (SSR) on home page
- Dynamic imports for heavy components

---

*Built for Nassaa Uth Hub, Besant Nagar, Chennai © 2025*
