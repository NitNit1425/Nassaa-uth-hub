-- ============================================================
-- NASSAA UTH HUB — Supabase Database Schema
-- ============================================================

-- Enable required extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pg_cron";

-- ============================================================
-- 1. USERS TABLE
-- ============================================================
create table public.users (
  id           uuid primary key references auth.users(id) on delete cascade,
  full_name    text not null default '',
  email        text not null,
  phone        text,
  role         text not null default 'user' check (role in ('user','admin')),
  avatar_url   text,
  xp_points    integer not null default 0,
  total_bookings integer not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- RLS
alter table public.users enable row level security;
create policy "Users can view own profile"  on public.users for select using (auth.uid() = id);
create policy "Users can update own profile" on public.users for update using (auth.uid() = id);
create policy "Admins can view all users"   on public.users for select using (
  exists (select 1 from public.users where id = auth.uid() and role = 'admin')
);

-- Auto-create user profile on sign-up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.users (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- 2. GAMES TABLE
-- ============================================================
create table public.games (
  id                  uuid primary key default uuid_generate_v4(),
  name                text not null,
  category            text not null check (category in ('bowling','vr','arcade','racing','laser','pool','karaoke')),
  description         text not null default '',
  short_desc          text not null default '',
  price               numeric(10,2) not null default 0,
  duration_minutes    integer not null default 30,
  max_players         integer not null default 4,
  image_url           text,
  preview_video_url   text,
  icon                text not null default '🎮',
  badge               text,
  badge_color         text check (badge_color in ('blue','pink','purple','green')),
  is_active           boolean not null default true,
  is_featured         boolean not null default false,
  created_at          timestamptz not null default now()
);

alter table public.games enable row level security;
create policy "Anyone can view active games" on public.games for select using (is_active = true);
create policy "Admins can manage games" on public.games for all using (
  exists (select 1 from public.users where id = auth.uid() and role = 'admin')
);

-- Seed games data
insert into public.games (name, category, short_desc, description, price, duration_minutes, max_players, icon, badge, badge_color, is_featured) values
('Bowling Arena',   'bowling', '12 premium neon lanes with auto-scoring', 'Experience bowling like never before across 12 state-of-the-art lanes with neon lighting, automatic pin-setting, and real-time digital scoring.', 250, 45, 6, '🎳', 'POPULAR', 'blue', true),
('VR Showdown',     'vr',      'Full-body VR combat in 10+ worlds',       'Strap in for full-body virtual reality combat across 10+ immersive battlefields. Haptic suits available for premium sessions.', 350, 30, 2, '🥽', 'HOT', 'pink', true),
('Boxing VR',       'vr',      'Hyper-realistic VR boxing experience',    'Punch, duck, and weave your way through ranked boxing matches in photorealistic VR arenas. Burn calories while having a blast.', 300, 30, 2, '🥊', 'VR', 'purple', false),
('Racing Simulator','racing',  'F1-grade cockpit with force feedback',    'Authentic Formula 1 racing experience with motion platform, force-feedback steering, and real track layouts from around the world.', 300, 30, 1, '🏎', 'VR', 'purple', true),
('Arcade Zone',     'arcade',  '60+ classic and modern arcade games',     'A curated collection of over 60 arcade machines spanning retro classics and modern gaming — perfect for all ages.', 200, 60, 4, '🕹', 'FUN', 'green', false),
('Laser Tag',       'laser',   'Multi-level arena laser combat',          'Multi-level arena laser tag for groups of 4-16. Tactical missions, custom loadouts, and team-based objectives make every session unique.', 400, 45, 16, '🎯', 'HOT', 'pink', true),
('Pool Tables',     'pool',    'Professional 9-ball and 8-ball tables',   'Premium slate-bed pool tables in a stylish lounge environment. 9-ball, 8-ball, and snooker configurations available.', 150, 30, 2, '🎱', 'CHILL', 'blue', false),
('Karaoke Rooms',   'karaoke', 'Private soundproofed rooms for groups',   'Fully soundproofed private karaoke rooms with 5000+ songs across every genre. Perfect for parties and group fun.', 600, 60, 8, '🎤', 'PARTY', 'pink', false);

-- ============================================================
-- 3. SLOTS TABLE
-- ============================================================
create table public.slots (
  id               uuid primary key default uuid_generate_v4(),
  game_id          uuid not null references public.games(id) on delete cascade,
  date             date not null,
  time             time not null,
  available_spots  integer not null default 4,
  total_spots      integer not null default 4,
  status           text not null default 'available' check (status in ('available','booked','blocked','locked')),
  locked_by        uuid references public.users(id),
  locked_until     timestamptz,
  created_at       timestamptz not null default now(),
  unique(game_id, date, time)
);

alter table public.slots enable row level security;
create policy "Anyone can view slots" on public.slots for select using (true);
create policy "Authenticated users can lock slots" on public.slots for update
  using (auth.uid() is not null)
  with check (status in ('locked', 'available'));
create policy "Admins can manage slots" on public.slots for all
  using (exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Function: lock a slot temporarily (5 min hold)
create or replace function public.lock_slot(p_slot_id uuid, p_user_id uuid)
returns json language plpgsql security definer as $$
declare
  v_slot record;
begin
  select * into v_slot from public.slots where id = p_slot_id for update;

  if not found then
    return json_build_object('success', false, 'message', 'Slot not found');
  end if;

  if v_slot.status = 'booked' or v_slot.available_spots = 0 then
    return json_build_object('success', false, 'message', 'Slot is fully booked');
  end if;

  if v_slot.status = 'locked' and v_slot.locked_until > now() and v_slot.locked_by != p_user_id then
    return json_build_object('success', false, 'message', 'Slot is temporarily held by another user');
  end if;

  update public.slots set
    status = 'locked',
    locked_by = p_user_id,
    locked_until = now() + interval '5 minutes'
  where id = p_slot_id;

  return json_build_object('success', true, 'message', 'Slot locked for 5 minutes');
end;
$$;

-- Function: release expired locks
create or replace function public.release_expired_locks()
returns void language plpgsql security definer as $$
begin
  update public.slots set
    status = 'available',
    locked_by = null,
    locked_until = null
  where status = 'locked' and locked_until < now();
end;
$$;

-- Cron: release locks every minute
select cron.schedule('release-slot-locks', '* * * * *', 'select public.release_expired_locks()');

-- ============================================================
-- 4. BOOKINGS TABLE
-- ============================================================
create table public.bookings (
  id              uuid primary key default uuid_generate_v4(),
  booking_ref     text not null unique default 'NUH-' || upper(substring(md5(random()::text), 1, 8)),
  user_id         uuid not null references public.users(id) on delete cascade,
  game_id         uuid not null references public.games(id),
  slot_id         uuid not null references public.slots(id),
  players         integer not null default 1,
  total_amount    numeric(10,2) not null,
  payment_status  text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  payment_id      text,
  booking_status  text not null default 'pending' check (booking_status in ('pending','confirmed','cancelled','completed')),
  qr_code         text,
  notes           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.bookings enable row level security;
create policy "Users can view own bookings" on public.bookings for select using (auth.uid() = user_id);
create policy "Users can create bookings"   on public.bookings for insert with check (auth.uid() = user_id);
create policy "Admins can view all bookings" on public.bookings for all
  using (exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- On booking confirmed → update slot + user XP
create or replace function public.on_booking_confirmed()
returns trigger language plpgsql security definer as $$
begin
  if new.booking_status = 'confirmed' and old.booking_status != 'confirmed' then
    -- Update slot to booked
    update public.slots set status = 'booked', available_spots = available_spots - new.players
    where id = new.slot_id;

    -- Award XP
    update public.users set
      xp_points = xp_points + floor(new.total_amount / 10),
      total_bookings = total_bookings + 1
    where id = new.user_id;
  end if;
  return new;
end;
$$;
create trigger booking_confirmed_trigger after update on public.bookings
  for each row execute procedure public.on_booking_confirmed();

-- ============================================================
-- 5. LEADERBOARD TABLE
-- ============================================================
create table public.leaderboard (
  id            uuid primary key default uuid_generate_v4(),
  game_id       uuid references public.games(id),
  user_id       uuid references public.users(id),
  player_name   text not null,
  player_avatar text,
  score         integer not null default 0,
  xp_earned     integer not null default 0,
  badge         text,
  created_at    timestamptz not null default now()
);

alter table public.leaderboard enable row level security;
create policy "Anyone can view leaderboard" on public.leaderboard for select using (true);
create policy "Admins can manage leaderboard" on public.leaderboard for all
  using (exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Seed leaderboard
insert into public.leaderboard (player_name, player_avatar, score, xp_earned, badge) values
('Arjun_X99',     '👑', 148900, 9800, 'LEGEND'),
('PixelKing_CN',  '🎮', 132450, 8600, 'PRO'),
('StrikeQueen',   '⚡', 119200, 7900, 'PRO'),
('Vikram_FPS',    '🎯', 98550,  6200, 'PRO'),
('NeonRacer22',   '🔥', 87100,  5400, 'PRO'),
('ArcadeGod',     '🕹', 74800,  4100, 'VETERAN'),
('ChennaiGamer',  '🏎', 63200,  3500, 'VETERAN'),
('LaserShot99',   '🎯', 52400,  2900, 'SKILLED');

-- ============================================================
-- 6. EVENTS TABLE
-- ============================================================
create table public.events (
  id                     uuid primary key default uuid_generate_v4(),
  title                  text not null,
  description            text not null default '',
  event_date             timestamptz not null,
  registration_deadline  timestamptz not null,
  max_participants       integer not null default 32,
  current_participants   integer not null default 0,
  entry_fee              numeric(10,2) not null default 0,
  prize_pool             text,
  image_url              text,
  status                 text not null default 'upcoming' check (status in ('upcoming','live','completed','cancelled')),
  category               text not null default 'general',
  created_at             timestamptz not null default now()
);

alter table public.events enable row level security;
create policy "Anyone can view events" on public.events for select using (true);
create policy "Admins can manage events" on public.events for all
  using (exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Seed events
insert into public.events (title, description, event_date, registration_deadline, max_participants, entry_fee, prize_pool, status, category) values
('Bowling Championship 2025', 'The ultimate bowling showdown. Top 32 players battle for the crown.', now() + interval '18 days', now() + interval '15 days', 32, 299, '₹25,000 Cash + Trophies', 'upcoming', 'bowling'),
('VR Marathon Night', 'An all-night VR gaming marathon. Last player standing wins.', now() + interval '25 days', now() + interval '22 days', 24, 399, '₹15,000 + Gaming Gear', 'upcoming', 'vr'),
('Retro Arcade Wars', 'Classic arcade tournament across 10 iconic titles.', now() + interval '33 days', now() + interval '30 days', 40, 199, '₹10,000 + Merch', 'upcoming', 'arcade');

-- ============================================================
-- 7. BOOKING DETAILS VIEW
-- ============================================================
create view public.booking_details as
select
  b.id, b.booking_ref,
  u.full_name as user_name, u.email as user_email, u.phone as user_phone,
  g.name as game_name, g.category as game_category, g.icon as game_icon,
  s.date as slot_date, s.time as slot_time,
  b.players, b.total_amount, b.payment_status, b.booking_status,
  b.qr_code, b.created_at
from public.bookings b
join public.users u on u.id = b.user_id
join public.games g on g.id = b.game_id
join public.slots s on s.id = b.slot_id;

-- ============================================================
-- 8. REALTIME ENABLE
-- ============================================================
alter publication supabase_realtime add table public.slots;
alter publication supabase_realtime add table public.leaderboard;
alter publication supabase_realtime add table public.bookings;

-- ============================================================
-- 9. STORAGE BUCKETS
-- ============================================================
insert into storage.buckets (id, name, public) values ('game-images', 'game-images', true);
insert into storage.buckets (id, name, public) values ('event-posters', 'event-posters', true);
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', false);

create policy "Public read game images" on storage.objects for select
  using (bucket_id = 'game-images');
create policy "Admins upload game images" on storage.objects for insert
  using (bucket_id = 'game-images' and exists (
    select 1 from public.users where id = auth.uid() and role = 'admin'
  ));
create policy "Users manage avatars" on storage.objects for all
  using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
