import type { Metadata } from 'next'
import { Orbitron, Rajdhani, Share_Tech_Mono } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/shared/Providers'
import { GlobalLoader } from '@/components/shared/GlobalLoader'
import { CustomCursor } from '@/components/shared/CustomCursor'
import { ParticleCanvas } from '@/components/shared/ParticleCanvas'
import { Navbar } from '@/components/shared/Navbar'
import { ChatBot } from '@/components/shared/ChatBot'
import { Toaster } from 'react-hot-toast'

const orbitron = Orbitron({ subsets: ['latin'], variable: '--font-orbitron', display: 'swap', weight: ['400','600','700','900'] })
const rajdhani = Rajdhani({ subsets: ['latin'], variable: '--font-rajdhani', display: 'swap', weight: ['300','400','500','600','700'] })
const shareTech = Share_Tech_Mono({ subsets: ['latin'], variable: '--font-share-tech', display: 'swap', weight: '400' })

export const metadata: Metadata = {
  title: "Nassaa Uth Hub — Gaming Universe | Besant Nagar, Chennai",
  description: "Chennai's most immersive gaming hub. Bowling, VR, Arcade & beyond.",
  keywords: 'gaming hub chennai, bowling besant nagar, vr gaming chennai',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${orbitron.variable} ${rajdhani.variable} ${shareTech.variable} font-rajdhani bg-[#030508] text-blue-50 overflow-x-hidden`}>
        <Providers>
          <GlobalLoader />
          <CustomCursor />
          <ParticleCanvas />
          <Navbar />
          <main className="relative z-10">{children}</main>
          <ChatBot />
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: 'rgba(3,5,8,0.95)',
                border: '1px solid rgba(0,212,255,0.3)',
                color: '#e0f4ff',
                fontFamily: 'var(--font-rajdhani)',
                backdropFilter: 'blur(20px)',
              },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
