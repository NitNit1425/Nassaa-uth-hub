import { HeroSection } from '@/components/sections/HeroSection'
import { GamesSection } from '@/components/sections/GamesSection'
import { StatsSection } from '@/components/sections/StatsSection'
import { LeaderboardSection } from '@/components/sections/LeaderboardSection'
import { EventsSection } from '@/components/sections/EventsSection'
import { AmenitiesSection } from '@/components/sections/AmenitiesSection'
import { ContactSection } from '@/components/sections/ContactSection'
import { NeonDivider } from '@/components/ui/NeonDivider'
import { createClient } from '@/supabase/server'

export default async function HomePage() {
  const supabase = createClient()
  const [{ data: games }, { data: leaderboard }, { data: events }] = await Promise.all([
    supabase.from('games').select('*').eq('is_active', true).order('is_featured', { ascending: false }),
    supabase.from('leaderboard').select('*').order('score', { ascending: false }).limit(8),
    supabase.from('events').select('*').eq('status', 'upcoming').order('event_date').limit(3),
  ])

  return (
    <>
      <HeroSection />
      <NeonDivider />
      <StatsSection />
      <NeonDivider />
      <GamesSection games={games ?? []} />
      <NeonDivider />
      <LeaderboardSection initialData={leaderboard ?? []} />
      <NeonDivider />
      <EventsSection events={events ?? []} />
      <NeonDivider />
      <AmenitiesSection />
      <NeonDivider />
      <ContactSection />
    </>
  )
}
