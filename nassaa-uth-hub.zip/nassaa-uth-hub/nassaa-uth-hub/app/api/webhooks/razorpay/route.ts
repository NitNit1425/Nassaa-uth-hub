import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/supabase/server'
import crypto from 'crypto'

export async function POST(req: NextRequest) {
  const body      = await req.text()
  const signature = req.headers.get('x-razorpay-signature')
  const secret    = process.env.RAZORPAY_WEBHOOK_SECRET!
  const expected  = crypto.createHmac('sha256', secret).update(body).digest('hex')
  if (signature !== expected) return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })

  const event   = JSON.parse(body)
  const adminSb = createAdminClient()

  if (event.event === 'payment.captured') {
    const paymentId = event.payload.payment.entity.id
    const bookingId = event.payload.payment.entity.notes?.booking_id
    if (bookingId) {
      await adminSb.from('bookings').update({
        payment_status: 'paid', payment_id: paymentId, booking_status: 'confirmed',
        qr_code: `NUH-QR-${bookingId}`,
      }).eq('id', bookingId)
    }
  }
  return NextResponse.json({ received: true })
}
