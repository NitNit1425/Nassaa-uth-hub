import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/supabase/server'
import { createAdminClient } from '@/supabase/server'

export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { gameId, slotId, players, totalAmount, name, phone } = body

  // Lock the slot
  const adminSb = createAdminClient()
  const { data: lockResult } = await adminSb.rpc('lock_slot', { p_slot_id: slotId, p_user_id: session.user.id })
  if (!lockResult?.success) return NextResponse.json({ error: lockResult?.message }, { status: 400 })

  // Create pending booking
  const { data: booking, error } = await adminSb.from('bookings').insert({
    user_id: session.user.id, game_id: gameId, slot_id: slotId,
    players, total_amount: totalAmount, payment_status: 'pending', booking_status: 'pending',
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ booking })
}

export async function GET(req: NextRequest) {
  const supabase = createClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: bookings } = await supabase
    .from('booking_details').select('*')
    .eq('user_id', session.user.id)
    .order('created_at', { ascending: false })

  return NextResponse.json({ bookings })
}
