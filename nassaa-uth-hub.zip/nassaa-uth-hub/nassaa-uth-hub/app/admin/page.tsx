'use client'
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { createClient } from '@/supabase/client'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Users, Calendar, DollarSign, TrendingUp, Activity, Download } from 'lucide-react'
import type { BookingDetail } from '@/types/supabase'

const METRICS = [
  { label:'Total Revenue',  icon: DollarSign, color:'#00d4ff',  key:'revenue',   prefix:'₹' },
  { label:'Total Bookings', icon: Calendar,   color:'#b200ff',  key:'bookings',  prefix:'' },
  { label:'Active Users',   icon: Users,      color:'#ff0099',  key:'users',     prefix:'' },
  { label:'Avg Rating',     icon: TrendingUp, color:'#00ff88',  key:'rating',    prefix:'' },
]

const CHART_DATA = [
  { day:'Mon', revenue:12400, bookings:24 },
  { day:'Tue', revenue:18200, bookings:35 },
  { day:'Wed', revenue:15800, bookings:30 },
  { day:'Thu', revenue:22400, bookings:42 },
  { day:'Fri', revenue:31200, bookings:58 },
  { day:'Sat', revenue:48900, bookings:84 },
  { day:'Sun', revenue:42100, bookings:72 },
]

export default function AdminDashboard() {
  const [bookings, setBookings] = useState<BookingDetail[]>([])
  const [stats, setStats] = useState({ revenue: 284500, bookings: 1247, users: 892, rating: 4.9 })
  const supabase = createClient()

  useEffect(() => {
    supabase.from('booking_details').select('*').order('created_at', { ascending:false }).limit(10)
      .then(({ data }) => { if (data) setBookings(data) })
  }, [])

  const exportCSV = () => {
    const rows = [['ID','Name','Email','Game','Date','Time','Amount','Status']]
    bookings.forEach(b => rows.push([b.booking_ref, b.user_name, b.user_email, b.game_name, b.slot_date, b.slot_time, String(b.total_amount), b.booking_status]))
    const csv = rows.map(r => r.join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type:'text/csv' }))
    const a = document.createElement('a'); a.href = url; a.download = 'bookings.csv'; a.click()
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="mb-8 flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="section-tag">⚡ ADMIN PANEL</div>
            <h1 className="font-orbitron font-black text-3xl grad-headline-2 mt-1">Command Center</h1>
          </div>
          <button onClick={exportCSV} className="flex items-center gap-2 font-orbitron text-xs font-bold tracking-wider text-[#00ff88] border border-[#00ff88]/30 px-4 py-2.5 rounded-lg hover:bg-[#00ff88]/10 transition-all">
            <Download size={14} /> EXPORT CSV
          </button>
        </motion.div>

        {/* Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {METRICS.map((m, i) => {
            const Icon = m.icon
            return (
              <motion.div key={m.key} initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.08 }}
                className="glass-card rounded-xl p-5 relative overflow-hidden">
                <div className="absolute inset-0 opacity-5" style={{ background:`radial-gradient(circle at 100% 0%, ${m.color}, transparent)` }} />
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background:`${m.color}15`, border:`1px solid ${m.color}30` }}>
                    <Icon size={18} style={{ color:m.color }} />
                  </div>
                  <div className="flex items-center gap-1 font-mono text-[0.6rem] text-[#00ff88]">
                    <Activity size={10} /> +12.5%
                  </div>
                </div>
                <div className="font-orbitron font-black text-2xl mb-0.5" style={{ color:m.color }}>
                  {m.prefix}{stats[m.key as keyof typeof stats].toLocaleString()}
                </div>
                <div className="font-mono text-[0.65rem] tracking-wider text-white/30 uppercase">{m.label}</div>
              </motion.div>
            )
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-8">
          <div className="glass-card rounded-xl p-5">
            <h3 className="font-orbitron font-bold text-sm tracking-wider text-white mb-5">WEEKLY REVENUE</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={CHART_DATA}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip contentStyle={{ background:'rgba(3,5,8,0.95)', border:'1px solid rgba(0,212,255,0.3)', borderRadius:8, fontFamily:'monospace' }} />
                <Area type="monotone" dataKey="revenue" stroke="#00d4ff" fill="url(#revGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="glass-card rounded-xl p-5">
            <h3 className="font-orbitron font-bold text-sm tracking-wider text-white mb-5">DAILY BOOKINGS</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={CHART_DATA}>
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip contentStyle={{ background:'rgba(3,5,8,0.95)', border:'1px solid rgba(178,0,255,0.3)', borderRadius:8, fontFamily:'monospace' }} />
                <Bar dataKey="bookings" fill="#b200ff" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bookings Table */}
        <div className="glass-card rounded-xl overflow-hidden">
          <div className="p-5 border-b border-white/5 flex items-center justify-between">
            <h3 className="font-orbitron font-bold text-sm tracking-wider text-white">RECENT BOOKINGS</h3>
            <span className="font-mono text-[0.6rem] tracking-widest text-white/25">{bookings.length} RECORDS</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  {['Booking ID','Player','Game','Date','Time','Amount','Status'].map(h => (
                    <th key={h} className="px-4 py-3 text-left font-mono text-[0.62rem] tracking-widest uppercase text-white/25">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bookings.length === 0 && (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-white/20 font-mono text-sm">No bookings yet</td></tr>
                )}
                {bookings.map((b, i) => (
                  <tr key={b.id} className="admin-table-row border-b border-white/[0.03] transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-[#00d4ff]">{b.booking_ref}</td>
                    <td className="px-4 py-3">
                      <div className="font-rajdhani font-semibold text-white text-sm">{b.user_name}</div>
                      <div className="text-white/30 text-xs">{b.user_email}</div>
                    </td>
                    <td className="px-4 py-3 font-rajdhani text-white/70 text-sm">{b.game_name}</td>
                    <td className="px-4 py-3 font-mono text-xs text-white/50">{b.slot_date}</td>
                    <td className="px-4 py-3 font-mono text-xs text-white/50">{b.slot_time}</td>
                    <td className="px-4 py-3 font-orbitron font-bold text-sm text-[#00ff88]">₹{b.total_amount}</td>
                    <td className="px-4 py-3">
                      <span className={`font-mono text-[0.6rem] tracking-wider px-2 py-1 rounded border ${
                        b.booking_status === 'confirmed' ? 'bg-[#00ff88]/10 text-[#00ff88] border-[#00ff88]/30' :
                        b.booking_status === 'pending'   ? 'bg-[#ffd700]/10 text-[#ffd700] border-[#ffd700]/30' :
                        'bg-[#ff0099]/10 text-[#ff0099] border-[#ff0099]/30'
                      }`}>{b.booking_status.toUpperCase()}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
