'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { createClient } from '@/supabase/client'
import { Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'

export default function RegisterPage() {
  const [form, setForm] = useState({ name:'', email:'', phone:'', password:'' })
  const [loading, setLoad] = useState(false)
  const router  = useRouter()
  const supabase = createClient()
  const up = (k: string, v: string) => setForm(f => ({ ...f, [k]:v }))

  const signUp = async () => {
    if (!form.name || !form.email || !form.password) { toast.error('Please fill all required fields'); return }
    setLoad(true)
    const { error } = await supabase.auth.signUp({
      email: form.email, password: form.password,
      options: { data: { full_name: form.name, phone: form.phone } }
    })
    if (error) { toast.error(error.message); setLoad(false) }
    else { toast.success('Account created! Check your email to verify.'); router.push('/auth/login') }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-24"
      style={{ background:'radial-gradient(ellipse 60% 60% at 50% 50%, rgba(178,0,255,0.1), transparent)' }}>
      <motion.div className="w-full max-w-md" initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }}>
        <div className="text-center mb-8">
          <div className="font-orbitron font-black text-3xl mb-2 grad-headline-2">JOIN THE HUB</div>
          <p className="text-white/40 text-sm">Create your gaming profile</p>
        </div>
        <div className="glass-card rounded-2xl p-8 space-y-4">
          {[
            { key:'name',     label:'Full Name',      type:'text',     ph:'Your name' },
            { key:'email',    label:'Email Address',  type:'email',    ph:'you@email.com' },
            { key:'phone',    label:'Phone Number',   type:'tel',      ph:'+91 98765 43210' },
            { key:'password', label:'Password',       type:'password', ph:'Min 8 characters' },
          ].map(f => (
            <div key={f.key}>
              <label className="font-mono text-[0.68rem] tracking-widest uppercase text-white/35 block mb-2">{f.label}</label>
              <input className="neon-input" type={f.type} placeholder={f.ph} value={form[f.key as keyof typeof form]} onChange={e => up(f.key, e.target.value)} />
            </div>
          ))}
          <motion.button onClick={signUp} disabled={loading}
            className="w-full py-4 rounded-xl font-orbitron font-bold text-sm tracking-widest text-white mt-2 flex items-center justify-center gap-2"
            style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}
            whileHover={{ scale:1.02 }} whileTap={{ scale:0.97 }}>
            {loading ? <Loader2 className="animate-spin" size={18} /> : '🎮 CREATE ACCOUNT'}
          </motion.button>
          <p className="text-center text-white/35 text-sm font-rajdhani">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-[#00d4ff] hover:underline">Sign in</Link>
          </p>
        </div>
      </motion.div>
    </div>
  )
}
