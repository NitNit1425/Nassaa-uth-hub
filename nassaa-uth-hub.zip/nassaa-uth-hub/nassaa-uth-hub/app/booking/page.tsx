'use client'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useBookingStore } from '@/store'
import { createClient } from '@/supabase/client'
import type { Game, Slot } from '@/types/supabase'
import { format, addDays, isBefore, startOfDay } from 'date-fns'
import { Check, ChevronRight, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import Confetti from 'react-confetti'
import QRCode from 'react-qr-code'

// ── Step indicators ──
const STEPS = ['Game', 'Date', 'Slot', 'Details', 'Done']

function StepBar({ current }: { current: number }) {
  return (
    <div className="flex items-center gap-0 mb-8">
      {STEPS.map((s, i) => (
        <div key={s} className="flex items-center flex-1 last:flex-none">
          <div className="flex flex-col items-center">
            <div className={`w-9 h-9 rounded-full border-2 flex items-center justify-center font-orbitron text-xs font-bold transition-all duration-400 ${
              i < current   ? 'border-[#00ff88] bg-[#00ff88]/20 text-[#00ff88]' :
              i === current ? 'border-[#00d4ff] bg-[#00d4ff]/15 text-[#00d4ff] shadow-[0_0_20px_rgba(0,212,255,0.4)]' :
                              'border-white/10 text-white/20'
            }`}>
              {i < current ? <Check size={14} /> : i+1}
            </div>
            <span className={`font-mono text-[0.6rem] tracking-wider mt-1 ${i === current ? 'text-[#00d4ff]' : 'text-white/25'}`}>{s}</span>
          </div>
          {i < STEPS.length-1 && (
            <div className={`flex-1 h-px mx-2 transition-all duration-500 ${i < current ? 'bg-[#00ff88]/50' : 'bg-white/10'}`} />
          )}
        </div>
      ))}
    </div>
  )
}

// ── Step 1: Select Game ──
function Step1Games({ games, onSelect }: { games: Game[], onSelect: (g: Game) => void }) {
  return (
    <div>
      <h3 className="font-orbitron font-bold text-xl mb-2 text-white">Choose Your Game</h3>
      <p className="text-white/40 text-sm mb-6">Select the experience you want to book</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {games.map((g) => (
          <motion.button key={g.id} onClick={() => onSelect(g)} whileHover={{ scale:1.02 }} whileTap={{ scale:0.98 }}
            className="flex items-center gap-4 p-4 rounded-xl border border-white/10 bg-white/[0.02] hover:border-[#00d4ff]/50 hover:bg-[#00d4ff]/08 transition-all text-left">
            <span className="text-3xl" style={{ filter:'drop-shadow(0 0 8px rgba(0,212,255,0.5))' }}>{g.icon}</span>
            <div className="flex-1 min-w-0">
              <div className="font-orbitron text-sm font-bold text-white">{g.name}</div>
              <div className="text-white/40 text-xs mt-0.5">{g.short_desc}</div>
            </div>
            <div className="text-right flex-shrink-0">
              <div className="font-orbitron font-bold text-sm" style={{ color:'#00ff88' }}>₹{g.price}</div>
              <div className="text-white/25 text-xs">{g.duration_minutes}min</div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  )
}

// ── Step 2: Select Date ──
function Step2Date({ onSelect, selected }: { onSelect: (d: Date) => void, selected: Date | null }) {
  const days = Array.from({ length: 14 }, (_, i) => addDays(new Date(), i))
  return (
    <div>
      <h3 className="font-orbitron font-bold text-xl mb-2 text-white">Choose a Date</h3>
      <p className="text-white/40 text-sm mb-6">Available for the next 2 weeks</p>
      <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
        {days.map((d) => {
          const isSelected = selected && format(d,'yyyy-MM-dd') === format(selected,'yyyy-MM-dd')
          return (
            <motion.button key={d.toString()} onClick={() => onSelect(d)} whileHover={{ scale:1.05 }} whileTap={{ scale:0.95 }}
              className={`p-3 rounded-xl border text-center transition-all ${
                isSelected ? 'border-[#00d4ff] bg-[#00d4ff]/20 shadow-neon-blue' : 'border-white/10 bg-white/[0.02] hover:border-[#00d4ff]/40'
              }`}>
              <div className="font-mono text-[0.6rem] text-white/35 tracking-wider">{format(d,'EEE')}</div>
              <div className={`font-orbitron font-bold text-lg ${isSelected ? 'text-[#00d4ff]' : 'text-white'}`}>{format(d,'d')}</div>
              <div className="font-mono text-[0.6rem] text-white/35">{format(d,'MMM')}</div>
            </motion.button>
          )
        })}
      </div>
    </div>
  )
}

// ── Step 3: Select Slot ──
function Step3Slots({ game, date, onSelect, selected }: { game: Game, date: Date, onSelect: (s: Slot) => void, selected: Slot | null }) {
  const [slots, setSlots]   = useState<Slot[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      const { data } = await supabase.from('slots')
        .select('*')
        .eq('game_id', game.id)
        .eq('date', format(date, 'yyyy-MM-dd'))
        .order('time')
      if (data && data.length > 0) {
        setSlots(data)
      } else {
        // Auto-generate slots for demo
        const times = ['10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00']
        const mockSlots: Slot[] = times.map((t, i) => ({
          id: `mock-${i}`, game_id: game.id, date: format(date,'yyyy-MM-dd'), time: t,
          available_spots: [2,4,4,4,0,4,4,4,0,4,4,2][i],
          total_spots: 4, status: [2,4,4,4,0,4,4,4,0,4,4,2][i] === 0 ? 'booked' : 'available',
          locked_by: null, locked_until: null, created_at: new Date().toISOString(),
        }))
        setSlots(mockSlots)
      }
      setLoading(false)
    }
    load()

    // Realtime slot updates
    const channel = supabase.channel('slots-live')
      .on('postgres_changes', { event: 'UPDATE', schema:'public', table:'slots', filter:`game_id=eq.${game.id}` }, (p) => {
        setSlots((prev) => prev.map((s) => s.id === p.new.id ? { ...s, ...p.new } as Slot : s))
      }).subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [game.id, date])

  if (loading) return (
    <div className="flex items-center justify-center py-16">
      <Loader2 className="animate-spin text-[#00d4ff]" size={32} />
    </div>
  )

  return (
    <div>
      <h3 className="font-orbitron font-bold text-xl mb-2 text-white">Choose a Time Slot</h3>
      <p className="text-white/40 text-sm mb-6">
        {format(date, 'EEEE, MMMM d, yyyy')} — {game.name}
      </p>
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
        {slots.map((s) => {
          const isFull   = s.status === 'booked' || s.available_spots === 0
          const isLocked = s.status === 'locked'
          const isSel    = selected?.id === s.id
          return (
            <motion.button key={s.id} disabled={isFull || isLocked} onClick={() => !isFull && !isLocked && onSelect(s)}
              whileHover={!isFull && !isLocked ? { scale:1.05 } : {}} whileTap={!isFull ? { scale:0.95 } : {}}
              className={`p-3 rounded-xl border font-mono text-sm text-center transition-all ${
                isSel    ? 'slot-selected' :
                isFull   ? 'slot-full' :
                isLocked ? 'slot-locked' :
                            'slot-available'
              }`}>
              {s.time.slice(0,5)}
              <div className="text-[0.58rem] mt-0.5 tracking-wider">
                {isFull ? 'FULL' : isLocked ? 'HELD' : `${s.available_spots} left`}
              </div>
            </motion.button>
          )
        })}
      </div>
      <div className="flex gap-4 mt-5 flex-wrap">
        {[['slot-available','Available'],['slot-selected','Selected'],['slot-locked','Held (5min)'],['slot-full','Full']].map(([cls,lbl]) => (
          <div key={lbl} className={`flex items-center gap-2 text-[0.65rem] font-mono tracking-wider`}>
            <div className={`w-3 h-3 rounded ${cls}`} />
            <span className="text-white/30">{lbl}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Step 4: Contact Details ──
function Step4Details({ onSubmit, loading }: { onSubmit: (data: { name:string, phone:string, email:string, players:number }) => void, loading: boolean }) {
  const [form, setForm] = useState({ name:'', phone:'', email:'', players:1 })
  const up = (k: string, v: string|number) => setForm((f) => ({ ...f, [k]:v }))

  return (
    <div>
      <h3 className="font-orbitron font-bold text-xl mb-2 text-white">Your Details</h3>
      <p className="text-white/40 text-sm mb-6">We&apos;ll send your booking confirmation here</p>
      <div className="space-y-4">
        <div>
          <label className="font-mono text-[0.72rem] tracking-widest uppercase text-white/40 block mb-2">Full Name</label>
          <input className="neon-input" placeholder="Your full name" value={form.name} onChange={(e) => up('name', e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-[0.72rem] tracking-widest uppercase text-white/40 block mb-2">Phone Number</label>
          <input className="neon-input" type="tel" placeholder="+91 98765 43210" value={form.phone} onChange={(e) => up('phone', e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-[0.72rem] tracking-widest uppercase text-white/40 block mb-2">Email Address</label>
          <input className="neon-input" type="email" placeholder="you@email.com" value={form.email} onChange={(e) => up('email', e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-[0.72rem] tracking-widest uppercase text-white/40 block mb-2">Number of Players</label>
          <div className="flex gap-2">
            {[1,2,3,4,5,6].map((n) => (
              <button key={n} onClick={() => up('players', n)}
                className={`w-11 h-11 rounded-lg border font-orbitron font-bold text-sm transition-all ${
                  form.players === n ? 'border-[#00d4ff] bg-[#00d4ff]/20 text-[#00d4ff]' : 'border-white/10 text-white/40 hover:border-[#00d4ff]/40'
                }`}>{n}</button>
            ))}
          </div>
        </div>
        <motion.button
          className="w-full py-4 rounded-xl font-orbitron font-bold text-sm tracking-widest text-white mt-2 flex items-center justify-center gap-2"
          style={{ background:'linear-gradient(135deg,#00d4ff,#b200ff)' }}
          onClick={() => onSubmit(form)}
          disabled={loading}
          whileHover={{ scale:1.02 }} whileTap={{ scale:0.98 }}
        >
          {loading ? <Loader2 className="animate-spin" size={18} /> : <>PROCEED TO PAYMENT <ChevronRight size={16} /></>}
        </motion.button>
      </div>
    </div>
  )
}

// ── Step 5: Success ──
function Step5Success({ bookingRef }: { bookingRef: string }) {
  return (
    <div className="text-center py-8">
      <Confetti numberOfPieces={200} recycle={false} colors={['#00d4ff','#b200ff','#ff0099','#00ff88','#ffd700']} />
      <motion.div className="text-6xl mb-4" animate={{ scale:[1,1.3,1] }} transition={{ duration:0.5 }}>🎉</motion.div>
      <h3 className="font-orbitron font-black text-2xl mb-2 grad-headline-2">BOOKING CONFIRMED!</h3>
      <p className="text-white/50 text-sm mb-6">Your slot is locked. QR code sent to your phone.</p>
      <div className="inline-block p-4 bg-white rounded-xl mb-4">
        <QRCode value={bookingRef} size={120} />
      </div>
      <div className="font-mono text-xs tracking-widest text-[#00ff88] border border-[#00ff88]/20 bg-[#00ff88]/05 px-4 py-2.5 rounded-lg inline-block">
        BOOKING ID: {bookingRef}
      </div>
      <p className="text-white/30 text-xs mt-4">Show this QR at the counter to enter</p>
    </div>
  )
}

// ── Main Booking Page ──
export default function BookingPage() {
  const { step, setStep, selectedGame, selectedDate, selectedSlot, bookingRef, setGame, setDate, setSlot, setContact, setPaymentSuccess, reset } = useBookingStore()
  const [games, setGames]     = useState<Game[]>([])
  const [submitting, setSub]  = useState(false)
  const supabase = createClient()

  useEffect(() => {
    supabase.from('games').select('*').eq('is_active', true).then(({ data }) => { if (data) setGames(data) })
  }, [])

  const handleConfirm = async (contact: { name:string, phone:string, email:string, players:number }) => {
    if (!selectedGame || !selectedSlot) return
    setSub(true)
    try {
      // For demo: simulate payment & booking confirmation
      await new Promise(r => setTimeout(r, 2000))
      const ref = 'NUH-' + Math.random().toString(36).substr(2,8).toUpperCase()
      setContact(contact.name, contact.phone, contact.email)
      setPaymentSuccess('pay_demo_' + Date.now(), ref)
      toast.success('Booking confirmed! 🎮')
    } catch {
      toast.error('Something went wrong. Please try again.')
    } finally {
      setSub(false)
    }
  }

  return (
    <div className="min-h-screen pt-28 pb-16 px-6"
      style={{ background:'radial-gradient(ellipse 60% 60% at 30% 50%, rgba(178,0,255,0.08), transparent)' }}>
      <div className="max-w-3xl mx-auto">
        <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="mb-8 text-center">
          <div className="section-tag mx-auto w-fit">⚡ BOOK YOUR SLOT</div>
          <h1 className="font-orbitron font-black text-3xl md:text-4xl mt-2">
            <span className="grad-headline-2">Reserve Your</span> Gaming Slot
          </h1>
        </motion.div>

        <div className="glass-card rounded-2xl p-6 md:p-8">
          <StepBar current={step - 1} />

          <AnimatePresence mode="wait">
            <motion.div key={step}
              initial={{ opacity:0, x:30 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-30 }}
              transition={{ duration:0.3, ease:[0.23,1,0.32,1] }}>
              {step === 1 && <Step1Games games={games} onSelect={(g) => { setGame(g); setStep(2) }} />}
              {step === 2 && selectedGame && <Step2Date onSelect={(d) => { setDate(d); setStep(3) }} selected={selectedDate} />}
              {step === 3 && selectedGame && selectedDate && (
                <Step3Slots game={selectedGame} date={selectedDate} onSelect={(s) => { setSlot(s); setStep(4) }} selected={selectedSlot} />
              )}
              {step === 4 && <Step4Details onSubmit={handleConfirm} loading={submitting} />}
              {step === 5 && bookingRef && <Step5Success bookingRef={bookingRef} />}
            </motion.div>
          </AnimatePresence>

          {/* Booking summary */}
          {step > 1 && step < 5 && (
            <div className="mt-6 pt-5 border-t border-white/5 flex flex-wrap gap-3 text-xs font-mono tracking-wider text-white/30">
              {selectedGame && <span>🎮 {selectedGame.name}</span>}
              {selectedDate && <span>📅 {format(selectedDate,'MMM d, yyyy')}</span>}
              {selectedSlot && <span>⏰ {selectedSlot.time.slice(0,5)}</span>}
              <button onClick={() => setStep((step > 1 ? step - 1 : 1) as 1|2|3|4|5)} className="ml-auto text-[#00d4ff] hover:underline">← Back</button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
