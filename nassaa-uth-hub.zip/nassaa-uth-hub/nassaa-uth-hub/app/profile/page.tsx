'use client'
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useAuthStore } from '@/store'
import { createClient } from '@/supabase/client'
import type { BookingDetail } from '@/types/supabase'
import { format } from 'date-fns'

export default function ProfilePage() {
  const user = useAuthStore((s) => s.user)
  const [bookings, setBookings] = useState<BookingDetail[]>([])
  const supabase = createClient()

  useEffect(() => {
    if (!user) return
    supabase.from('booking_details').select('*').order('created_at', { ascending:false }).limit(10)
      .then(({ data }) => { if (data) setBookings(data) })
  }, [user])

  if (!user) return null
  const xpPct = Math.min(100, (user.xp_points / 10000) * 100)

  return (
    <div className="min-h-screen pt-28 pb-16 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Profile Card */}
        <motion.div initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }}
          className="glass-card rounded-2xl p-8 mb-6">
          <div className="flex items-start gap-6 flex-wrap">
            <div className="w-20 h-20 rounded-full border-2 border-[#00d4ff]/40 bg-[#00d4ff]/10 flex items-center justify-center text-4xl">
              {user.avatar_url ? <img src={user.avatar_url} className="w-full h-full rounded-full object-cover" alt="avatar" /> : '👤'}
            </div>
            <div className="flex-1">
              <h1 className="font-orbitron font-black text-2xl text-white">{user.full_name}</h1>
              <p className="text-white/40 text-sm mb-3">{user.email}</p>
              <div className="flex gap-4 flex-wrap">
                <div className="text-center">
                  <div className="font-orbitron font-bold text-lg text-[#00d4ff]">{user.total_bookings}</div>
                  <div className="font-mono text-[0.6rem] text-white/30 tracking-wider">BOOKINGS</div>
                </div>
                <div className="text-center">
                  <div className="font-orbitron font-bold text-lg text-[#b200ff]">{user.xp_points.toLocaleString()}</div>
                  <div className="font-mono text-[0.6rem] text-white/30 tracking-wider">XP POINTS</div>
                </div>
                <div className="text-center">
                  <div className="font-orbitron font-bold text-lg text-[#ffd700]">{user.role.toUpperCase()}</div>
                  <div className="font-mono text-[0.6rem] text-white/30 tracking-wider">ROLE</div>
                </div>
              </div>
            </div>
          </div>
          {/* XP Bar */}
          <div className="mt-5">
            <div className="flex justify-between font-mono text-[0.65rem] text-white/30 mb-2">
              <span>XP PROGRESS</span><span>{user.xp_points.toLocaleString()} / 10,000</span>
            </div>
            <div className="h-2 bg-white/5 rounded-full overflow-hidden">
              <motion.div className="xp-bar-fill h-full" initial={{ width:0 }} animate={{ width:`${xpPct}%` }} transition={{ duration:1.5, delay:0.3 }} />
            </div>
          </div>
        </motion.div>

        {/* Booking History */}
        <motion.div initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.15 }}
          className="glass-card rounded-2xl overflow-hidden">
          <div className="p-5 border-b border-white/5">
            <h2 className="font-orbitron font-bold text-sm tracking-wider text-white">BOOKING HISTORY</h2>
          </div>
          {bookings.length === 0 ? (
            <div className="py-12 text-center text-white/20 font-mono text-sm">No bookings yet. <a href="/booking" className="text-[#00d4ff]">Book your first slot!</a></div>
          ) : (
            <div className="divide-y divide-white/[0.04]">
              {bookings.map((b) => (
                <div key={b.id} className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.02] transition-colors flex-wrap">
                  <div className="w-10 h-10 rounded-lg bg-[#00d4ff]/08 border border-[#00d4ff]/15 flex items-center justify-center text-lg">🎮</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-rajdhani font-semibold text-white">{b.game_name}</div>
                    <div className="font-mono text-[0.65rem] text-white/30">{b.slot_date} · {b.slot_time}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-orbitron font-bold text-sm text-[#00ff88]">₹{b.total_amount}</div>
                    <div className="font-mono text-[0.6rem] text-white/25">{b.booking_ref}</div>
                  </div>
                  <span className={`font-mono text-[0.6rem] tracking-wider px-2 py-1 rounded border ${
                    b.booking_status === 'confirmed' ? 'bg-[#00ff88]/10 text-[#00ff88] border-[#00ff88]/30' :
                    'bg-[#ffd700]/10 text-[#ffd700] border-[#ffd700]/30'
                  }`}>{b.booking_status.toUpperCase()}</span>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
