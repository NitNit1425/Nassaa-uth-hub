/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        orbitron: ['var(--font-orbitron)', 'monospace'],
        rajdhani: ['var(--font-rajdhani)', 'sans-serif'],
        mono: ['var(--font-share-tech)', 'monospace'],
      },
      colors: {
        neon: {
          blue:   '#00d4ff',
          purple: '#b200ff',
          pink:   '#ff0099',
          green:  '#00ff88',
          gold:   '#ffd700',
        },
        game: {
          dark:    '#030508',
          darker:  '#010204',
          card:    'rgba(0,180,255,0.04)',
          glass:   'rgba(0,180,255,0.06)',
          border:  'rgba(0,212,255,0.3)',
        },
      },
      backgroundImage: {
        'hero-glow':    'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(0,100,200,0.18) 0%, transparent 70%)',
        'section-glow': 'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(0,80,160,0.1), transparent)',
        'neon-gradient':'linear-gradient(135deg, #00d4ff, #b200ff, #ff0099)',
      },
      animation: {
        'glitch':     'glitch 3s infinite',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite',
        'float':      'float 4s ease-in-out infinite',
        'scan-line':  'scanLine 4s linear infinite',
        'border-run': 'borderRun 3s linear infinite',
        'count-up':   'countUp 2s ease-out forwards',
      },
      keyframes: {
        glitch: {
          '0%,100%': { textShadow: 'none' },
          '2%':      { textShadow: '-3px 0 #ff0099, 3px 0 #00d4ff' },
          '4%':      { textShadow: 'none' },
          '96%':     { textShadow: '-2px 0 #b200ff' },
          '98%':     { textShadow: 'none' },
        },
        glowPulse: {
          '0%,100%': { boxShadow: '0 0 20px rgba(0,212,255,0.4)' },
          '50%':     { boxShadow: '0 0 50px rgba(178,0,255,0.6)' },
        },
        float: {
          '0%,100%': { transform: 'translateY(0px)' },
          '50%':     { transform: 'translateY(-15px)' },
        },
        scanLine: {
          '0%':   { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        borderRun: {
          '0%':   { backgroundPosition: '0% 50%' },
          '100%': { backgroundPosition: '200% 50%' },
        },
      },
      backdropBlur: { xs: '2px' },
      boxShadow: {
        'neon-blue':   '0 0 20px rgba(0,212,255,0.5), 0 0 60px rgba(0,212,255,0.2)',
        'neon-purple': '0 0 20px rgba(178,0,255,0.5), 0 0 60px rgba(178,0,255,0.2)',
        'neon-pink':   '0 0 20px rgba(255,0,153,0.5), 0 0 60px rgba(255,0,153,0.2)',
        'card-hover':  '0 20px 60px rgba(0,212,255,0.2), 0 0 40px rgba(178,0,255,0.1)',
      },
    },
  },
  plugins: [],
}
