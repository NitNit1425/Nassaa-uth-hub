export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          full_name: string
          email: string
          phone: string | null
          role: 'user' | 'admin'
          avatar_url: string | null
          xp_points: number
          total_bookings: number
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['users']['Insert']>
      }
      games: {
        Row: {
          id: string
          name: string
          category: 'bowling' | 'vr' | 'arcade' | 'racing' | 'laser' | 'pool' | 'karaoke'
          description: string
          short_desc: string
          price: number
          duration_minutes: number
          max_players: number
          image_url: string | null
          preview_video_url: string | null
          icon: string
          badge: string | null
          badge_color: 'blue' | 'pink' | 'purple' | 'green' | null
          is_active: boolean
          is_featured: boolean
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['games']['Row'], 'created_at'>
        Update: Partial<Database['public']['Tables']['games']['Insert']>
      }
      slots: {
        Row: {
          id: string
          game_id: string
          date: string
          time: string
          available_spots: number
          total_spots: number
          status: 'available' | 'booked' | 'blocked' | 'locked'
          locked_by: string | null
          locked_until: string | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['slots']['Row'], 'created_at'>
        Update: Partial<Database['public']['Tables']['slots']['Insert']>
      }
      bookings: {
        Row: {
          id: string
          booking_ref: string
          user_id: string
          game_id: string
          slot_id: string
          players: number
          total_amount: number
          payment_status: 'pending' | 'paid' | 'failed' | 'refunded'
          payment_id: string | null
          booking_status: 'pending' | 'confirmed' | 'cancelled' | 'completed'
          qr_code: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['bookings']['Row'], 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['bookings']['Insert']>
      }
      leaderboard: {
        Row: {
          id: string
          game_id: string
          user_id: string | null
          player_name: string
          player_avatar: string | null
          score: number
          xp_earned: number
          rank: number | null
          badge: string | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['leaderboard']['Row'], 'created_at'>
        Update: Partial<Database['public']['Tables']['leaderboard']['Insert']>
      }
      events: {
        Row: {
          id: string
          title: string
          description: string
          event_date: string
          registration_deadline: string
          max_participants: number
          current_participants: number
          entry_fee: number
          prize_pool: string | null
          image_url: string | null
          status: 'upcoming' | 'live' | 'completed' | 'cancelled'
          category: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['events']['Row'], 'created_at'>
        Update: Partial<Database['public']['Tables']['events']['Insert']>
      }
    }
    Views: {
      booking_details: {
        Row: {
          id: string
          booking_ref: string
          user_name: string
          user_email: string
          user_phone: string | null
          game_name: string
          game_category: string
          slot_date: string
          slot_time: string
          players: number
          total_amount: number
          payment_status: string
          booking_status: string
          created_at: string
        }
      }
    }
    Functions: {
      lock_slot: {
        Args: { p_slot_id: string; p_user_id: string }
        Returns: { success: boolean; message: string }
      }
      release_expired_locks: {
        Args: Record<never, never>
        Returns: void
      }
      get_leaderboard_with_rank: {
        Args: { p_game_id?: string; p_limit?: number }
        Returns: Array<Database['public']['Tables']['leaderboard']['Row'] & { rank: number }>
      }
    }
  }
}

// Convenience types
export type User = Database['public']['Tables']['users']['Row']
export type Game = Database['public']['Tables']['games']['Row']
export type Slot = Database['public']['Tables']['slots']['Row']
export type Booking = Database['public']['Tables']['bookings']['Row']
export type LeaderboardEntry = Database['public']['Tables']['leaderboard']['Row']
export type GameEvent = Database['public']['Tables']['events']['Row']
export type BookingDetail = Database['public']['Views']['booking_details']['Row']
